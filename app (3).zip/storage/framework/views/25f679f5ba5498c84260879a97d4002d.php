<?php $__env->startSection('title', $job->job_id); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow">EMERGENCY DESK · INCIDENT DETAILS</span><h1><?php echo e($job->job_id); ?></h1><p class="muted"><?php echo e($job->occurred_at->format('M j, Y g:i A')); ?> · <?php echo e($job->ward?->name ?? 'Ward not assigned'); ?></p></div>
        <div>
            <span class="status"><?php echo e(str_replace('_', ' ', $job->status)); ?></span>
            <?php if($canArchive): ?>
                <form method="POST" action="<?php echo e(route('app.jobs.archive', $job->id)); ?>" class="inline-form" onsubmit="return confirm('Archive this closed incident? It can be restored later.');">
                    <?php echo csrf_field(); ?>
                    <button class="button button-light" type="submit">Archive incident</button>
                </form>
            <?php endif; ?>
            <a class="button button-light" href="<?php echo e(route('app.jobs')); ?>">Back to incidents</a>
        </div>
    </div>
    <?php if(session('status')): ?> <div class="success-notice" role="status"><?php echo e(session('status')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?> <div class="alert" role="alert"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    <section class="panel incident-details-panel">
        <h2>Caller and incident</h2>
        <div class="form-grid incident-facts">
            <div><span>Caller</span><strong><?php echo e($job->caller_name); ?></strong></div>
            <div><span>Phone</span><strong><?php echo e($job->caller_phone); ?></strong></div>
            <div><span>Call source</span><strong><?php echo e(str_replace('_', ' ', $job->call_source)); ?></strong></div>
            <div><span>Type · priority</span><strong><?php echo e(str_replace('_', ' ', $job->incident_type)); ?> · <?php echo e($job->priority); ?></strong></div>
            <div class="field-wide"><span>Address</span><strong><?php echo e($job->incident_address); ?></strong></div>
            <div><span>Society / area</span><strong><?php echo e($job->society_name ?: 'Not recorded'); ?></strong></div>
            <div><span>Coordinates</span><strong><?php echo e($job->latitude && $job->longitude ? $job->latitude.', '.$job->longitude : 'Not recorded'); ?></strong></div>
            <div class="field-wide"><span>Intake remarks</span><strong><?php echo e($job->remarks ?: '—'); ?></strong></div>
        </div>
    </section>

    <?php if($job->assignments->isNotEmpty() || $canAssign): ?>
        <section class="panel">
            <div class="page-heading">
                <div><h2>Response units</h2><p class="muted">Each vehicle is assigned and tracked independently. Busy vehicle/driver pairs and response teams can be queued; the next assignment activates automatically when current work is released.</p></div>
            </div>
            <?php if($job->assignments->isNotEmpty()): ?>
                <div class="table-scroll"><table><thead><tr><th>Vehicle</th><th>Station</th><th>Team</th><th>Assigned by</th><th>Status</th><th>Update status</th></tr></thead><tbody>
                    <?php $__currentLoopData = $job->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($assignment->vehicle?->vehicle_number ?? 'Vehicle unavailable'); ?></strong></td>
                            <td><?php echo e($assignment->fireStation?->name ?? '—'); ?></td>
                            <td>
                                Driver: <?php echo e($assignment->assignedDriver?->name ?? 'Unassigned'); ?>

                                <?php if($assignment->team): ?>
                                    <br><small class="muted">Team: <?php echo e($assignment->team->name); ?><?php if($assignment->teamLeader): ?> · <?php echo e($assignment->teamLeader->name); ?><?php endif; ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($assignment->assigner?->name ?? 'System'); ?></td>
                            <td><span class="status"><?php echo e(str_replace('_', ' ', $assignment->status)); ?></span></td>
                            <td>
                                <?php if(in_array((string) $assignment->getKey(), $updatableAssignmentIds, true)): ?>
                                    <form method="POST" action="<?php echo e(route('app.jobs.assignments.status', [$job->id, $assignment->id])); ?>" class="managed-user-form incident-form">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <label>Status
                                            <select name="status">
                                                <?php $__currentLoopData = [
                                                    \App\Models\JobAssignment::STATUS_ASSIGNED => 'Assigned',
                                                    \App\Models\JobAssignment::STATUS_EN_ROUTE => 'En route',
                                                    \App\Models\JobAssignment::STATUS_ARRIVED => 'Arrived',
                                                    \App\Models\JobAssignment::STATUS_STARTED => 'Started',
                                                    \App\Models\JobAssignment::STATUS_IN_PROGRESS => 'In progress',
                                                    \App\Models\JobAssignment::STATUS_COMPLETED => 'Completed',
                                                    \App\Models\JobAssignment::STATUS_WORK_DONE => 'Work done',
                                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusValue => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($statusValue); ?>" <?php if($assignment->status === $statusValue): echo 'selected'; endif; ?>><?php echo e($statusLabel); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </label>
                                        <label>Update note<input name="remarks" maxlength="2000" placeholder="Optional"></label>
                                        <button class="button button-light" type="submit">Update</button>
                                    </form>
                                <?php else: ?>
                                    <span class="muted">Status update unavailable</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody></table></div>
            <?php else: ?>
                <p class="muted">No response units have been assigned yet.</p>
            <?php endif; ?>

            <?php if($canAssign): ?>
                <?php if($assignableStations->isNotEmpty()): ?>
                    <form method="POST" action="<?php echo e(route('app.jobs.assignments.store', $job->id)); ?>" class="managed-user-form incident-form assignment-form">
                        <?php echo csrf_field(); ?>
                        <h3>Assign one or more units</h3>
                        <p class="muted">A busy vehicle and driver can only be queued together as the same pair. Busy response teams can also be queued. Queued work activates automatically when the current assignment finishes. The station must cover this incident's ward.</p>
                        <div id="assignment-rows">
                            <div class="assignment-row form-grid">
                                <label>Fire station
                                    <select name="assignments[0][fire_station_id]" data-field="fire_station_id" class="assignment-station" required>
                                        <option value="">Select station</option>
                                        <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($station->id); ?>"><?php echo e($station->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label>Vehicle
                                    <select name="assignments[0][vehicle_id]" data-field="vehicle_id" class="assignment-vehicle" required>
                                        <option value="">Select vehicle</option>
                                        <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $station->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($vehicle->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($vehicle->vehicle_number); ?> · <?php echo e(str_replace('_', ' ', $vehicle->vehicle_type)); ?><?php if($vehicle->status === \App\Models\Vehicle::STATUS_DEPLOYED): ?> · Busy — may queue <?php endif; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label>Vehicle driver
                                    <select name="assignments[0][driver_user_id]" data-field="driver_user_id" class="assignment-driver" required>
                                        <option value="">Select driver</option>
                                        <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $station->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($driver->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($driver->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label>Response team (optional; busy teams queue)
                                    <select name="assignments[0][team_id]" data-field="team_id" class="assignment-team">
                                        <option value="">No team selected</option>
                                        <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $station->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($team->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($team->name); ?><?php if($team->status === \App\Models\Team::STATUS_DEPLOYED): ?> · Busy — will queue <?php endif; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <button class="button button-light" type="button" id="add-assignment-row">Add another vehicle</button>
                        <label>Dispatch notes<textarea name="remarks" rows="2" maxlength="2000"></textarea></label>
                        <button class="button button-primary" type="submit">Assign response units</button>
                    </form>
                    <template id="assignment-row-template">
                        <div class="assignment-row form-grid">
                            <label>Fire station
                                <select data-field="fire_station_id" class="assignment-station" required>
                                    <option value="">Select station</option>
                                    <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($station->id); ?>"><?php echo e($station->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>Vehicle
                                <select data-field="vehicle_id" class="assignment-vehicle" required>
                                    <option value="">Select vehicle</option>
                                    <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $station->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vehicle->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($vehicle->vehicle_number); ?> · <?php echo e(str_replace('_', ' ', $vehicle->vehicle_type)); ?><?php if($vehicle->status === \App\Models\Vehicle::STATUS_DEPLOYED): ?> · Busy — may queue <?php endif; ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>Vehicle driver
                                <select data-field="driver_user_id" class="assignment-driver" required>
                                    <option value="">Select driver</option>
                                    <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $station->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($driver->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($driver->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>Response team (optional; busy teams queue)
                                <select data-field="team_id" class="assignment-team">
                                    <option value="">No team selected</option>
                                    <?php $__currentLoopData = $assignableStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $station->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($team->id); ?>" data-station="<?php echo e($station->id); ?>"><?php echo e($team->name); ?><?php if($team->status === \App\Models\Team::STATUS_DEPLOYED): ?> · Busy — will queue <?php endif; ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <button class="button button-light remove-assignment-row" type="button">Remove vehicle</button>
                        </div>
                    </template>
                <?php else: ?>
                    <p class="muted">No station covering this incident ward has both an available On Road vehicle and an active vehicle driver.</p>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($job->status === \App\Models\EmergencyJob::STATUS_RECEIVED && ($canCloseDuplicate || $canTransferTo112)): ?>
        <section class="form-grid">
            <?php if($canCloseDuplicate): ?>
                <div class="panel">
                    <h2>Close as duplicate</h2>
                    <?php if($possibleDuplicates->isNotEmpty()): ?>
                        <p class="muted">Possible matches use the same caller number from the last 48 hours. Confirm the original before closing.</p>
                        <form method="POST" action="<?php echo e(route('app.jobs.duplicate', $job->id)); ?>" class="managed-user-form incident-form">
                            <?php echo csrf_field(); ?>
                            <label>Original incident
                                <select name="duplicate_of" required>
                                    <option value="">Select original incident</option>
                                    <?php $__currentLoopData = $possibleDuplicates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($candidate->id); ?>"><?php echo e($candidate->job_id); ?> · <?php echo e($candidate->incident_type); ?> · <?php echo e($candidate->occurred_at->format('M j, g:i A')); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>Closure note<textarea name="remarks" rows="2" maxlength="2000"></textarea></label>
                            <button class="button button-light" type="submit">Confirm duplicate</button>
                        </form>
                    <?php else: ?>
                        <p class="muted">No matching recent caller incidents were found.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if($canTransferTo112): ?>
                <div class="panel">
                    <h2>Transfer to 112</h2>
                    <p class="muted">Record the 112 reference number to keep the handoff auditable.</p>
                    <form method="POST" action="<?php echo e(route('app.jobs.transfer-112', $job->id)); ?>" class="managed-user-form incident-form">
                        <?php echo csrf_field(); ?>
                        <label>112 reference number<input name="reference_number" required maxlength="100"></label>
                        <label>Handoff details<textarea name="details" rows="2" maxlength="5000"></textarea></label>
                        <button class="button button-primary" type="submit">Record transfer</button>
                    </form>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($job->externalReferences->isNotEmpty()): ?>
        <section class="panel">
            <h2>External references</h2>
            <div class="table-scroll"><table><thead><tr><th>Type</th><th>Reference</th><th>Details</th><th>Recorded</th></tr></thead><tbody>
                <?php $__currentLoopData = $job->externalReferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><?php echo e($reference->reference_type); ?></td><td><strong><?php echo e($reference->reference_number); ?></strong></td><td><?php echo e($reference->details ?: '—'); ?></td><td><?php echo e(($reference->transferred_at ?? $reference->confirmed_at ?? $reference->created_at)->format('M j, Y g:i A')); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
        </section>
    <?php endif; ?>

    <section class="panel">
        <h2>Incident history</h2>
        <div class="table-scroll"><table><thead><tr><th>Time</th><th>Change</th><th>Unit</th><th>By</th><th>Notes</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $job->statusHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><?php echo e($history->changed_at->format('M j, Y g:i A')); ?></td><td><?php echo e($history->previous_status ? str_replace('_', ' ', $history->previous_status).' → ' : ''); ?><strong><?php echo e(str_replace('_', ' ', $history->new_status)); ?></strong></td><td><?php echo e($history->assignment?->vehicle?->vehicle_number ?? 'Incident'); ?></td><td><?php echo e($history->actor?->name ?? 'System'); ?></td><td><?php echo e($history->remarks ?: '—'); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="empty-cell">No incident history recorded.</td></tr>
            <?php endif; ?>
        </tbody></table></div>
    </section>
</section>
<script>
    (() => {
        const rows = document.getElementById('assignment-rows');
        const template = document.getElementById('assignment-row-template');
        const addButton = document.getElementById('add-assignment-row');
        if (!rows || !template || !addButton) return;

        const filterResources = (row) => {
            const stationId = row.querySelector('.assignment-station').value;
            row.querySelectorAll('.assignment-vehicle option[data-station], .assignment-driver option[data-station], .assignment-team option[data-station]').forEach((option) => {
                const available = !stationId || option.dataset.station === stationId;
                option.hidden = !available;
                option.disabled = !available;
                if (!available && option.selected) option.selected = false;
            });
        };

        const renumberRows = () => {
            rows.querySelectorAll('.assignment-row').forEach((row, index) => {
                row.querySelectorAll('[data-field]').forEach((field) => {
                    field.name = `assignments[${index}][${field.dataset.field}]`;
                });
            });
        };

        const addRow = () => {
            if (rows.children.length >= 10) return;
            const row = template.content.firstElementChild.cloneNode(true);
            row.querySelector('.assignment-station').addEventListener('change', () => filterResources(row));
            row.querySelector('.remove-assignment-row').addEventListener('click', () => {
                row.remove();
                renumberRows();
            });
            rows.appendChild(row);
            renumberRows();
        };

        rows.querySelector('.assignment-station').addEventListener('change', () => filterResources(rows.firstElementChild));
        addButton.addEventListener('click', addRow);
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/incidents/show.blade.php ENDPATH**/ ?>