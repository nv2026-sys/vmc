

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div>
            <span class="eyebrow">PERSONAL UPDATES</span>
            <h1>Notifications</h1>
            <p class="muted"><?php echo e($unreadCount); ?> unread notification<?php echo e($unreadCount === 1 ? '' : 's'); ?></p>
        </div>
        <?php if($unreadCount > 0): ?>
            <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>">
                <?php echo csrf_field(); ?>
                <button class="button button-light" type="submit">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>
    <?php if(session('status')): ?>
        <div class="success-notice" role="status"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <section class="panel">
        <div class="table-scroll">
            <table>
                <thead><tr><th>Update</th><th>Incident</th><th>Time</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $data = $notification->data;
                        $event = $data['event'] ?? '';
                        $title = match ($event) {
                            'dispatch.assigned', 'assignment.created' => 'New assignment',
                            'assignment.status_changed' => 'Assignment status updated',
                            'vehicle.operational_status_changed' => 'Vehicle status updated',
                            default => str($event)->replace(['driver_assignment.', '_'], ['', ' '])->title()->toString() ?: 'Notification',
                        };
                        $summary = $data['message'] ?? $data['remarks'] ?? $data['reason'] ?? null;
                        $detail = $data['incident_type'] ?? null;
                        if (!$detail && isset($data['previous_status'], $data['new_status'])) {
                            $detail = $data['previous_status'].' → '.$data['new_status'];
                        }
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo e($title); ?></strong>
                            <?php if($summary): ?><small><?php echo e($summary); ?></small><?php endif; ?>
                            <?php if(!empty($data['vehicle_number'])): ?><small>Vehicle: <?php echo e($data['vehicle_number']); ?></small><?php endif; ?>
                            <?php if(!empty($data['team_name'])): ?><small>Team: <?php echo e($data['team_name']); ?></small><?php endif; ?>
                        </td>
                        <td><?php echo e($data['job_id'] ?? $data['vehicle_number'] ?? '—'); ?><small><?php echo e(str_replace('_', ' ', $detail ?? '')); ?></small></td>
                        <td><?php echo e($notification->created_at?->format('M j, Y g:i A')); ?></td>
                        <td><span class="status <?php echo e($notification->read_at ? 'status-inactive' : 'status-active'); ?>"><?php echo e($notification->read_at ? 'Read' : 'Unread'); ?></span></td>
                        <td>
                            <?php if(!$notification->read_at): ?>
                                <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="text-link" type="submit">Mark read</button>
                                </form>
                            <?php endif; ?>
                            <?php if(!empty($data['incident_id'])): ?>
                                <a class="text-link" href="<?php echo e(route('app.jobs.show', $data['incident_id'])); ?>">View incident</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty-cell">You have no notifications yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination"><?php echo e($notifications->links()); ?></div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/notifications/index.blade.php ENDPATH**/ ?>