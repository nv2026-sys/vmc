<?php $__env->startSection('title', $managedUser->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow">USER ACCOUNT · #<?php echo e($managedUser->id); ?></span><h1><?php echo e($managedUser->name); ?></h1><p class="muted"><?php echo e($managedUser->email); ?></p></div>
        <div class="heading-actions"><a class="button button-light" href="<?php echo e(route('users.index')); ?>">← User list</a><?php if($canEdit): ?><a class="button button-primary" href="<?php echo e(route('users.edit', $managedUser)); ?>">Edit account</a><?php endif; ?></div>
    </div>
    <?php if(session('status')): ?><div class="success-notice" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
    <div class="user-detail-grid">
        <section class="panel detail-panel">
            <div class="panel-heading"><div><h2>Account overview</h2><p>Current access and account status</p></div><span class="status <?php echo e($managedUser->is_active ? 'status-active' : 'status-inactive'); ?>"><?php echo e($managedUser->is_active ? 'Active' : 'Inactive'); ?></span></div>
            <dl class="detail-list">
                <div><dt>Account ID</dt><dd>#<?php echo e($managedUser->id); ?></dd></div>
                <div><dt>Role hierarchy</dt><dd><?php echo e($managedUser->roles->pluck('name')->join(', ') ?: 'No role assigned'); ?></dd></div>
                <div><dt>Assigned stations</dt><dd><?php echo e($stations->pluck('name')->join(', ') ?: 'No station assigned'); ?></dd></div>
                <div><dt>Member since</dt><dd><?php echo e($managedUser->created_at?->format('M j, Y') ?? '—'); ?></dd></div>
                <div><dt>Last sign in</dt><dd><?php echo e($managedUser->last_login_at?->format('M j, Y g:i A') ?? 'Never signed in'); ?></dd></div>
                <div><dt>Effective permissions</dt><dd><div class="permission-list"><?php echo e($managedUser->roles->flatMap(fn ($role) => $role->permissions->pluck('code'))->unique()->sort()->implode(', ') ?: 'None'); ?></div></dd></div>
            </dl>
        </section>
        <section class="panel detail-panel">
            <div class="panel-heading"><div><h2>Account activity</h2><p>Recent recorded actions for this user</p></div></div>
            <?php if($logs->isEmpty()): ?>
                <div class="empty-state compact-empty"><strong>No activity recorded yet</strong><p>Authentication and account-management events appear here.</p></div>
            <?php else: ?>
                <div class="activity-list">
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><span class="activity-dot"></span><span><strong><?php echo e(str($log->event)->replace('.', ' ')->headline()); ?></strong><small><?php echo e($log->created_at?->format('M j, Y g:i A') ?? 'Time unavailable'); ?></small></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
    <div class="hierarchy-note"><strong>Data visibility</strong><span>This page shows the account&apos;s roles, assigned stations, effective permissions, and recorded sign-in/activity history.</span></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/users/show.blade.php ENDPATH**/ ?>