<?php $__env->startSection('title', $user ? 'Edit user' : 'Add user'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow">USER HIERARCHY</span><h1><?php echo e($user ? 'Edit account' : 'Create account'); ?></h1><p class="muted">Set the account&apos;s role and the stations it can access.</p></div>
    </div>
    <section class="form-panel panel">
        <form method="POST" action="<?php echo e($user ? route('users.update', $user) : route('users.store')); ?>" class="managed-user-form">
            <?php echo csrf_field(); ?>
            <?php if($user): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert" role="alert"><strong>Check the form:</strong> <?php echo e($errors->first()); ?></div>
            <?php endif; ?>
            <div class="form-grid">
                <div class="field"><label for="name">Full name</label><input id="name" name="name" value="<?php echo e(old('name', $user?->name)); ?>" maxlength="255" autocomplete="name" required></div>
                <div class="field"><label for="email">Work email</label><input id="email" name="email" type="email" value="<?php echo e(old('email', $user?->email)); ?>" maxlength="255" autocomplete="email" required></div>
                <div class="field"><label for="role_code">Account role</label>
                    <?php ($selectedRole = old('role_code', $user?->roles->first()?->code)); ?>
                    <select id="role_code" name="role_code" required>
                        <option value="">Select an allowed role</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->code); ?>" <?php if($selectedRole === $role->code): echo 'selected'; endif; ?>><?php echo e($role->name); ?> · <?php echo e($role->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field"><label for="password"><?php echo e($user ? 'New password (optional)' : 'Temporary password'); ?></label><input id="password" name="password" type="password" minlength="14" maxlength="255" autocomplete="new-password" <?php echo e($user ? '' : 'required'); ?>><small><?php echo e($user ? 'Leave blank to keep the current password.' : 'At least 14 characters. Share it through a secure channel.'); ?></small></div>
            </div>

            <fieldset class="station-fieldset">
                <legend>Station access <span>Choose only the stations this account needs.</span></legend>
                <?php $__errorArgs = ['station_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="station-choice-grid">
                    <?php ($selectedStations = collect(old('station_ids', $user?->fireStations->modelKeys() ?? []))->map(fn ($id) => (int) $id)->all()); ?>
                    <?php $__empty_1 = true; $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label class="station-choice">
                            <input type="checkbox" name="station_ids[]" value="<?php echo e($station->id); ?>" <?php if(in_array($station->id, $selectedStations, true)): echo 'checked'; endif; ?>>
                            <span><strong><?php echo e($station->name); ?></strong><small><?php echo e($station->code); ?></small></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="muted">No stations are available in your scope. Ask a higher-level administrator to assign your station.</p>
                    <?php endif; ?>
                </div>
            </fieldset>

            <label class="active-choice">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $user?->is_active ?? true)): echo 'checked'; endif; ?>>
                <span><strong>Account active</strong><small>Inactive accounts cannot sign in; active API tokens are revoked when disabled.</small></span>
            </label>

            <div class="form-actions"><a class="button button-light" href="<?php echo e($user ? route('users.show', $user) : route('users.index')); ?>">Cancel</a><button class="button button-primary" type="submit"><?php echo e($user ? 'Save changes' : 'Create user'); ?></button></div>
        </form>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/users/form.blade.php ENDPATH**/ ?>