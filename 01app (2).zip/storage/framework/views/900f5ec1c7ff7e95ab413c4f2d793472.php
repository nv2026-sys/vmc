

<?php $__env->startSection('title', 'Quick call'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .quick-call-page { max-width: 760px; margin: 0 auto; }
    .quick-call-form { gap: 14px; }
    .quick-call-form .form-grid { gap: 12px; }
    .quick-call-form label { font-size: 13px !important; }
    .quick-call-form input, .quick-call-form select, .quick-call-form textarea {
        min-height: 46px;
        padding: 10px 12px;
        font-size: 16px !important;
    }
    .quick-call-form textarea { min-height: 72px; }
    .quick-call-form .form-actions { justify-content: stretch; }
    .quick-call-form .form-actions > * { flex: 1; min-height: 46px; }
    .quick-call-error { color: #a63737; font-size: 13px; }
    @media (max-width: 650px) {
        .quick-call-page { width: 100%; }
        .quick-call-form .form-grid { grid-template-columns: minmax(0, 1fr); }
    }
</style>
<section class="page-stack quick-call-page">
    <div class="page-heading">
        <div>
            <span class="eyebrow">EMERGENCY DESK · QUICK INTAKE</span>
            <h1>Quick call</h1>
            <p class="muted">Capture the essentials now. You can assign response units or add more details next.</p>
        </div>
        <a class="button button-light" href="<?php echo e(route('app.jobs.new')); ?>">Full registration</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert" role="alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <section class="panel">
        <form method="POST" action="<?php echo e(route('app.jobs.quick-call.store')); ?>" class="managed-user-form incident-form quick-call-form">
            <?php echo csrf_field(); ?>
            <div class="form-grid">
                <label>Caller name
                    <input name="caller_name" value="<?php echo e(old('caller_name')); ?>" required maxlength="255" autocomplete="name" autofocus>
                </label>
                <label>Caller phone
                    <input name="caller_phone" type="tel" value="<?php echo e(old('caller_phone')); ?>" required maxlength="32" autocomplete="tel" inputmode="tel">
                </label>
                <label>Incident type
                    <select name="incident_type" required>
                        <option value="">Select type</option>
                        <?php $__currentLoopData = ['STRUCTURE_FIRE' => 'Structure fire', 'VEHICLE_FIRE' => 'Vehicle fire', 'ROAD_ACCIDENT' => 'Road accident', 'MEDICAL_EMERGENCY' => 'Medical emergency', 'RESCUE' => 'Rescue', 'OTHER' => 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('incident_type') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Priority
                    <select name="priority" required>
                        <?php $__currentLoopData = ['LOW' => 'Low', 'NORMAL' => 'Normal', 'HIGH' => 'High', 'CRITICAL' => 'Critical']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('priority', 'HIGH') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Ward
                    <select name="ward_id" required>
                        <option value="">Select ward</option>
                        <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ward->id); ?>" <?php if((string) old('ward_id') === (string) $ward->id): echo 'selected'; endif; ?>><?php echo e($ward->name); ?> · <?php echo e($ward->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Area / society
                    <input name="society_name" value="<?php echo e(old('society_name')); ?>" required maxlength="255" autocomplete="address-level3">
                </label>
                <label class="field-wide">Incident address / location
                    <textarea name="incident_address" required maxlength="2000" rows="2" autocomplete="street-address"><?php echo e(old('incident_address')); ?></textarea>
                </label>
                <?php echo $__env->make('incidents.partials.location-picker', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <label class="field-wide">Short remarks <span class="muted">(optional)</span>
                    <textarea name="remarks" maxlength="500" rows="2"><?php echo e(old('remarks')); ?></textarea>
                </label>
            </div>
            <div class="form-actions">
                <a class="button button-light" href="<?php echo e(route('app.jobs')); ?>">Cancel</a>
                <button class="button button-primary" type="submit">Register incident</button>
            </div>
        </form>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/incidents/quick-call.blade.php ENDPATH**/ ?>