

<?php $__env->startSection('title', 'Incident registered'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack" style="max-width: 760px; margin: 0 auto;">
    <div class="success-notice" role="status">
        Incident <strong><?php echo e($job->job_id); ?></strong> registered successfully.
    </div>
    <section class="panel">
        <span class="eyebrow">INCIDENT RECEIVED</span>
        <h1><?php echo e($job->incident_type === 'OTHER' ? 'Other emergency' : str_replace('_', ' ', $job->incident_type)); ?></h1>
        <p class="muted"><?php echo e($job->society_name); ?> · <?php echo e($job->ward?->name); ?> · <?php echo e($job->incident_address); ?></p>
        <p><strong>Caller:</strong> <?php echo e($job->caller_name); ?> · <a href="tel:<?php echo e($job->caller_phone); ?>"><?php echo e($job->caller_phone); ?></a></p>
        <div class="form-actions">
            <?php if($canAssign): ?>
                <a class="button button-primary" href="<?php echo e(route('app.jobs.show', $job).'#assignment-rows'); ?>">Assign one or more vehicles</a>
            <?php endif; ?>
            <?php if($canViewDetails): ?>
                <a class="button button-light" href="<?php echo e(route('app.jobs.show', $job)); ?>">Open incident details</a>
            <?php endif; ?>
            <a class="button button-light" href="<?php echo e(route('app.jobs.quick-call')); ?>">Register another call</a>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/incidents/quick-call-confirmation.blade.php ENDPATH**/ ?>