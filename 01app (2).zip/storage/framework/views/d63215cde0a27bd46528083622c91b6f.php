<?php $__env->startSection('title', 'Live GPS tracking'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack tracking-page">
    <div class="page-heading">
        <div>
            <span class="eyebrow">FIELD OPERATIONS · LIVE FLEET</span>
            <h1>Live GPS tracking</h1>
            <p class="muted">Authenticated vehicle locations and assignment route history. Positions stay within your station access.</p>
        </div>
        <span class="tracking-live"><i></i> GPS feed</span>
    </div>

    <section class="tracking-layout">
        <div class="panel tracking-map-panel">
            <div class="tracking-panel-heading">
                <div><h2><?php echo e($selectedIncident ? 'Incident location map' : 'Fleet location map'); ?></h2><p><?php echo e($selectedIncident ? $selectedIncident->job_id.' · '.$selectedIncident->incident_address : 'Vehicle GPS locations refresh automatically every 15 seconds.'); ?></p></div>
                <span class="tracking-count"><?php echo e($vehicles->count()); ?> tracked <?php echo e(\Illuminate\Support\Str::plural('vehicle', $vehicles->count())); ?></span>
            </div>
            <link rel="stylesheet" href="<?php echo e(asset('css/dashboard-live-map.css')); ?>?v=<?php echo e(filemtime(public_path('css/dashboard-live-map.css'))); ?>">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
            <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
            <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
            <div class="operations-dashboard-layout ops-tracking-map-scope">
                <div class="ops-live-map-toolbar">
                    <label class="ops-map-search">Vehicle
                        <input type="search" data-map-search-vehicle placeholder="Search vehicle no.">
                    </label>
                    <div class="ops-map-control-group" role="group" aria-label="Map layers and display">
                        <button type="button" data-map-layer="vehicles" aria-pressed="true">Vehicles</button>
                        <?php if(auth()->user()?->hasPermission('jobs.view')): ?>
                            <button type="button" data-map-layer="incidents" aria-pressed="true">Incidents</button>
                            <button type="button" data-map-layer="density" aria-pressed="true">Density</button>
                        <?php endif; ?>
                        <button type="button" data-map-fullscreen>Fullscreen</button>
                        <button type="button" data-map-satellite disabled title="Satellite imagery provider is not configured">Satellite</button>
                        <button type="button" data-map-boundaries disabled title="Ward boundary data is not available">Ward boundaries</button>
                        <button type="button" data-map-refresh>Refresh map</button>
                    </div>
                </div>
                <div class="ops-live-map-shell">
                    <div class="ops-live-map" id="ops-live-map" role="application" aria-label="Live vehicle GPS locations"
                        data-map-endpoint="<?php echo e($mapRefreshUrl); ?>"
                        data-map-auto-refresh="15000"
                        data-map-selected-vehicle="<?php echo e($selectedVehicle?->vehicle_number); ?>"
                        data-map-selected-incident="<?php echo e($selectedIncident?->job_id); ?>"
                        data-map-payload="<?php echo e(json_encode($mapData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)); ?>">
                    </div>
                    <p class="ops-live-map-message" data-map-message role="status" hidden></p>
                </div>
                <div class="ops-live-map-legend" aria-label="Map legend">
                    <span><i class="is-vehicle-on-road"></i> On Road / Moving</span>
                    <span><i class="is-vehicle-off-road"></i> Off Road</span>
                    <span><i class="is-vehicle-assigned"></i> Assigned</span>
                    <span><i class="is-vehicle-idle"></i> Idle / Free</span>
                    <span><i class="is-vehicle-at-incident"></i> At Incident / On Site</span>
                    <?php if(auth()->user()?->hasPermission('jobs.view')): ?>
                        <span><i class="is-incident-critical"></i> Critical incident</span>
                        <span><i class="is-incident-high"></i> High incident</span>
                        <span><i class="is-incident-medium"></i> Medium incident</span>
                        <span><i class="is-incident-low"></i> Low incident</span>
                        <span><i class="is-density"></i> Ward incident density</span>
                    <?php endif; ?>
                </div>
                <p class="ops-live-map-attribution">Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>. Positions show the latest authenticated GPS update.</p>
            </div>
            <script defer src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <script defer src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
            <script defer src="<?php echo e(asset('dashboard-live-map.js')); ?>?v=<?php echo e(filemtime(public_path('dashboard-live-map.js'))); ?>"></script>
        </div>

        <aside class="panel tracking-units-panel">
            <div class="tracking-panel-heading"><div><h2>Tracked vehicles</h2><p>Most recent received location</p></div></div>
            <?php if($vehicles->isNotEmpty()): ?>
                <div class="tracking-unit-list">
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isStale = $vehicle->latestGpsLog->recorded_at->lt(now()->subMinutes(5));
                            $activeAssignment = $vehicle->assignments->first();
                            $displayStatus = \App\Services\VehicleDisplayStatus::describe($vehicle, $activeAssignment);
                        ?>
                        <a class="tracking-unit <?php echo e($selectedVehicle?->is($vehicle) ? 'is-selected' : ''); ?>" data-map-vehicle="<?php echo e($vehicle->vehicle_number); ?>" data-map-ward-id="<?php echo e($activeAssignment?->emergencyJob?->ward_id); ?>" href="<?php echo e(url('/vehicles/'.$vehicle->id)); ?>">
                            <span class="tracking-unit-icon">⌖</span>
                            <span class="tracking-unit-details">
                                <strong><?php echo e($vehicle->vehicle_number); ?></strong>
                                <small><?php echo e($vehicle->fireStation?->name ?? 'Station unavailable'); ?></small>
                                <small><span class="vehicle-status-badge is-<?php echo e($displayStatus['class']); ?>"><?php echo e($displayStatus['label']); ?></span></small>
                                <?php if($activeAssignment?->emergencyJob): ?>
                                    <small><?php echo e($activeAssignment->emergencyJob->job_id); ?> · <?php echo e(str_replace('_', ' ', $activeAssignment->status)); ?></small>
                                <?php endif; ?>
                            </span>
                            <span class="tracking-unit-time <?php echo e($isStale ? 'is-stale' : ''); ?>"><?php echo e($isStale ? 'STALE' : 'FRESH'); ?><small><?php echo e($vehicle->latestGpsLog->recorded_at->diffForHumans()); ?></small></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="tracking-no-units">No vehicles in your authorized tracking scope.</p>
            <?php endif; ?>
        </aside>
    </section>

    <?php if($selectedVehicle): ?>
        <section class="panel tracking-history-panel">
            <div class="tracking-panel-heading">
                <div><h2>Route history · <?php echo e($selectedVehicle->vehicle_number); ?></h2><p><?php echo e($selectedVehicle->fireStation?->name); ?> · <?php echo e($routePoints->count()); ?> GPS points in this range</p></div>
                <form method="GET" action="<?php echo e(route('app.tracking')); ?>" class="tracking-filters">
                    <input type="hidden" name="vehicle_id" value="<?php echo e($selectedVehicle->id); ?>">
                    <label>Assignment
                        <select name="assignment_id">
                            <option value="">All my vehicle routes</option>
                            <?php $__currentLoopData = $routeAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($assignment->id); ?>" <?php if((string) ($filters['assignment_id'] ?? '') === (string) $assignment->id): echo 'selected'; endif; ?>><?php echo e($assignment->emergencyJob?->job_id ?? 'Job '.$assignment->emergency_job_id); ?> · <?php echo e(str_replace('_', ' ', $assignment->status)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>From<input type="datetime-local" name="from" value="<?php echo e(isset($filters['from']) ? \Illuminate\Support\Carbon::parse($filters['from'])->format('Y-m-d\\TH:i') : now()->subDay()->format('Y-m-d\\TH:i')); ?>"></label>
                    <label>To<input type="datetime-local" name="to" value="<?php echo e(isset($filters['to']) ? \Illuminate\Support\Carbon::parse($filters['to'])->format('Y-m-d\\TH:i') : now()->format('Y-m-d\\TH:i')); ?>"></label>
                    <button class="button button-light button-small" type="submit">Show route</button>
                </form>
            </div>
            <div class="table-scroll"><table><thead><tr><th>Recorded</th><th>Coordinates</th><th>Speed</th><th>Job</th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $routePoints->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($point['log']->recorded_at->format('M j, Y g:i:s A')); ?></td>
                        <td><?php echo e($point['log']->latitude); ?>, <?php echo e($point['log']->longitude); ?></td>
                        <td><?php echo e($point['log']->speed_kph !== null ? $point['log']->speed_kph.' km/h' : '—'); ?></td>
                        <td><?php echo e($point['log']->assignment?->emergencyJob?->job_id ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="empty-cell">No route points match this vehicle and time range.</td></tr>
                <?php endif; ?>
            </tbody></table></div>
        </section>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/tracking/index.blade.php ENDPATH**/ ?>