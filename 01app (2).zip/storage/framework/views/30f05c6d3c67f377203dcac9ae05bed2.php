<?php $__env->startSection('title', 'User management'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div>
            <span class="eyebrow">ROLE-BASED USER HIERARCHY</span>
            <h1>User management</h1>
            <p class="muted">Review each account&apos;s role, station assignments, and recent activity.</p>
        </div>
        <div class="page-heading-actions">
            <?php if(auth()->user()->hasPermission('users.manage')): ?>
                <a class="button button-primary" href="<?php echo e(route('users.create')); ?>">+ Add user</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if(session('status')): ?>
        <div class="success-notice" role="status"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <section class="panel directory-panel">
        <form class="directory-toolbar" method="GET" action="<?php echo e(route('users.index')); ?>">
            <div><h2>Authorized accounts</h2><p><?php echo e(number_format($users->total())); ?> users in your visibility scope</p></div>
            <div class="search-control"><input name="search" value="<?php echo e($search); ?>" placeholder="Search name, email, or role…" aria-label="Search users"><button class="button button-light button-small" type="submit">Search</button></div>
        </form>
        <div class="table-scroll">
            <table class="user-table">
                <thead><tr><th>User</th><th>Hierarchy role</th><th>Assigned stations</th><th>Status</th><th>Last sign in</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directoryUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $assignedStations = $directoryUser->fireStations->merge($directoryUser->managedFireStations)->unique('id');
                    ?>
                    <tr>
                        <td><a class="user-name-link" href="<?php echo e(route('users.show', $directoryUser)); ?>"><strong><?php echo e($directoryUser->name); ?></strong><small><?php echo e($directoryUser->email); ?></small></a></td>
                        <td><div class="role-badges"><?php $__empty_2 = true; $__currentLoopData = $directoryUser->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><span class="role-badge"><?php echo e(str_replace('_', ' ', $role->name)); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><span class="muted">No role assigned</span><?php endif; ?></div></td>
                        <td>
                            <div class="station-badges">
                                <?php $__empty_2 = true; $__currentLoopData = $assignedStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><span class="station-badge"><?php echo e($station->code); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><span class="muted">No station assigned</span><?php endif; ?>
                            </div>
                        </td>
                        <td><span class="status <?php echo e($directoryUser->is_active ? 'status-active' : 'status-inactive'); ?>"><?php echo e($directoryUser->is_active ? 'Active' : 'Inactive'); ?></span></td>
                        <td><?php echo e($directoryUser->last_login_at?->format('M j, Y g:i A') ?? 'Never'); ?></td>
                        <td class="user-actions">
                            <a class="text-link" href="<?php echo e(route('users.show', $directoryUser)); ?>">Details</a>
                            <?php if(in_array($directoryUser->id, $manageableUserIds, true)): ?>
                                <a class="text-link" href="<?php echo e(route('users.edit', $directoryUser)); ?>">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="empty-cell">No users match your search in the permitted station scope.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination"><?php echo e($users->links()); ?></div>
    </section>
    <div class="hierarchy-note"><strong>Account hierarchy</strong><span>Super Admin → Control Room Admin → Station Admin → Dispatcher / Report Viewer → Driver → Team Member</span><small>Administrators can only assign roles below their own level. Station administrators are limited to users and stations in their scope.</small></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/users/index.blade.php ENDPATH**/ ?>