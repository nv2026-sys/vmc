

<?php $__env->startSection('title', 'Vehicle details · '.$vehicle->vehicle_number); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack vehicle-details-page">
    <div class="page-heading">
        <div>
            <span class="eyebrow">FIELD OPERATIONS · VEHICLE</span>
            <h1><?php echo e($vehicle->vehicle_number); ?></h1>
            <p class="muted"><?php echo e($vehicle->fireStation?->name ?? 'Station unavailable'); ?> · <?php echo e(str_replace('_', ' ', $vehicle->vehicle_type)); ?></p>
        </div>
        <div class="page-heading-actions">
            <span class="vehicle-status-badge is-<?php echo e($status['class']); ?>"><?php echo e($status['label']); ?></span>
            <a class="button button-light button-small" href="<?php echo e(url('/vehicles')); ?>">All vehicles</a>
            <?php if(auth()->user()?->hasPermission('gps.view')): ?>
                <a class="button button-primary" href="<?php echo e(route('app.tracking', ['vehicle_id' => $vehicle->id])); ?>">View on tracking map →</a>
            <?php endif; ?>
        </div>
    </div>

    <section class="vehicle-details-summary" aria-label="Vehicle status">
        <article class="panel vehicle-summary-card">
            <span class="eyebrow">CURRENT STATUS</span>
            <strong><span class="vehicle-status-badge is-<?php echo e($status['class']); ?>"><?php echo e($status['label']); ?></span></strong>
            <small>Operational status is shown with the active assignment taking precedence.</small>
        </article>
        <article class="panel vehicle-summary-card">
            <span class="eyebrow">LATEST GPS UPDATE</span>
            <?php if($gpsLog): ?>
                <strong><?php echo e($gpsIsStale ? 'Stale' : 'Fresh'); ?></strong>
                <small><time datetime="<?php echo e($gpsLog->recorded_at->toIso8601String()); ?>"><?php echo e($gpsLog->recorded_at->format('M j, Y g:i A')); ?> (<?php echo e($gpsLog->recorded_at->diffForHumans()); ?>)</time></small>
            <?php else: ?>
                <strong>Unavailable</strong>
                <small>No GPS update has been recorded.</small>
            <?php endif; ?>
        </article>
        <article class="panel vehicle-summary-card">
            <span class="eyebrow">LAST KNOWN GPS POSITION</span>
            <?php if($gpsLog): ?>
                <strong><?php echo e(number_format((float) $gpsLog->latitude, 5)); ?>, <?php echo e(number_format((float) $gpsLog->longitude, 5)); ?></strong>
                <small>Recorded position; no location is inferred.</small>
            <?php else: ?>
                <strong>Location unavailable</strong>
                <small>Waiting for a recorded GPS position.</small>
            <?php endif; ?>
        </article>
        <article class="panel vehicle-summary-card">
            <span class="eyebrow">OPEN ASSIGNMENTS</span>
            <strong><?php echo e($assignments->count()); ?></strong>
            <small><?php echo e(\Illuminate\Support\Str::plural('active assignment', $assignments->count())); ?></small>
        </article>
    </section>

    <section class="panel vehicle-detail-panel" id="open-assignments">
        <div class="vehicle-section-heading">
            <div><h2>Open assignments</h2><p>Active assignments for this vehicle</p></div>
            <span><?php echo e($assignments->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('ticket', $assignments->count())); ?></span>
        </div>
        <div class="table-scroll">
            <table class="vehicle-detail-table">
                <thead><tr><th>Incident</th><th>Assignment status</th><th>Assigned</th><th>Team / driver</th><th>Action</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php if($canViewJobs && $assignment->emergencyJob): ?>
                                    <strong><a class="text-link" href="<?php echo e(route('app.jobs.show', $assignment->emergencyJob)); ?>"><?php echo e($assignment->emergencyJob->job_id); ?></a></strong>
                                    <small><?php echo e(str_replace('_', ' ', $assignment->emergencyJob->incident_type)); ?> · <?php echo e($assignment->emergencyJob->ward?->name ?? 'Ward unavailable'); ?></small>
                                <?php else: ?>
                                    <strong>Assignment #<?php echo e($assignment->id); ?></strong>
                                <?php endif; ?>
                            </td>
                            <td><span class="vehicle-status-badge is-<?php echo e(\Illuminate\Support\Str::slug($assignment->status, '_')); ?>"><?php echo e(str_replace('_', ' ', $assignment->status)); ?></span></td>
                            <td><?php echo e($assignment->assigned_at?->format('M j, Y g:i A') ?? 'Not recorded'); ?></td>
                            <td><?php echo e($assignment->team?->name ?? 'Team unavailable'); ?><small><?php echo e($assignment->assignedDriver?->name ?? 'Driver unavailable'); ?></small></td>
                            <td>
                                <?php if($canViewJobs && $assignment->emergencyJob): ?>
                                    <a class="text-link" href="<?php echo e(route('app.jobs.show', $assignment->emergencyJob)); ?>">View Details</a>
                                <?php else: ?>
                                    <span class="muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="empty-cell" colspan="5">No open assignments for this vehicle.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <?php if($canViewJobs): ?>
        <section class="panel vehicle-detail-panel" id="recently-closed-tickets">
            <div class="vehicle-section-heading">
                <div><h2>Recently closed tickets</h2><p>Latest close first · assignments previously handled by this vehicle</p></div>
                <?php if($closedIncidents instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
                    <span><?php echo e(number_format($closedIncidents->total())); ?> tickets</span>
                <?php endif; ?>
            </div>
            <div class="table-scroll">
                <table class="vehicle-detail-table">
                    <thead><tr><th>Ticket</th><th>Incident</th><th>Ward</th><th>Closed at</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $closedIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php ($closedStatus = $incident->statusHistory->first()); ?>
                            <tr>
                                <td><strong><?php echo e($incident->job_id); ?></strong></td>
                                <td><?php echo e(str_replace('_', ' ', $incident->incident_type)); ?></td>
                                <td><?php echo e($incident->ward?->name ?? '—'); ?></td>
                                <td>
                                    <?php if($incident->last_closed_at): ?>
                                        <time datetime="<?php echo e(\Illuminate\Support\Carbon::parse($incident->last_closed_at)->toIso8601String()); ?>"><?php echo e(\Illuminate\Support\Carbon::parse($incident->last_closed_at)->format('M j, Y g:i A')); ?></time>
                                    <?php else: ?>
                                        <span class="muted">Close time unavailable</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="vehicle-status-badge is-closed"><?php echo e(str_replace('_', ' ', $closedStatus?->new_status ?? $incident->status)); ?></span></td>
                                <td><a class="text-link" href="<?php echo e(route('app.jobs.show', $incident)); ?>">View Details</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td class="empty-cell" colspan="6">No closed tickets are associated with this vehicle.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($closedIncidents instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator && $closedIncidents->hasPages()): ?>
                <div class="vehicle-pagination">
                    <span>Showing <?php echo e($closedIncidents->firstItem()); ?>–<?php echo e($closedIncidents->lastItem()); ?> of <?php echo e(number_format($closedIncidents->total())); ?></span>
                    <?php echo e($closedIncidents->fragment('recently-closed-tickets')->links()); ?>

                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($canViewJobs): ?>
        <section class="panel vehicle-detail-panel">
            <div class="vehicle-section-heading"><div><h2>Assignment / incident status history</h2><p>Recorded status changes only</p></div></div>
            <div class="vehicle-history-list">
                <?php $__empty_1 = true; $__currentLoopData = $assignmentHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="vehicle-history-entry">
                        <span class="vehicle-history-marker"></span>
                        <div>
                            <strong><?php echo e(str_replace('_', ' ', $history->previous_status ?: 'Created')); ?> → <?php echo e(str_replace('_', ' ', $history->new_status)); ?></strong>
                            <p>
                                <?php if($history->assignment?->emergencyJob): ?>
                                    <a class="text-link" href="<?php echo e(route('app.jobs.show', $history->assignment->emergencyJob)); ?>"><?php echo e($history->assignment->emergencyJob->job_id); ?></a> ·
                                <?php endif; ?>
                                <?php echo e($history->actor?->name ?? 'System'); ?>

                            </p>
                            <small><?php echo e($history->changed_at?->format('M j, Y g:i A') ?? 'Time unavailable'); ?><?php echo e($history->remarks ? ' · '.$history->remarks : ''); ?></small>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty-cell">No assignment status history is available for this vehicle.</p>
                <?php endif; ?>
            </div>
            <?php if($assignmentHistory instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator && $assignmentHistory->hasPages()): ?>
                <div class="vehicle-pagination">
                    <span>Showing <?php echo e($assignmentHistory->firstItem()); ?>–<?php echo e($assignmentHistory->lastItem()); ?> of <?php echo e(number_format($assignmentHistory->total())); ?></span>
                    <?php echo e($assignmentHistory->links()); ?>

                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($vehicleHistory->isNotEmpty()): ?>
        <section class="panel vehicle-detail-panel">
            <div class="vehicle-section-heading"><div><h2>Vehicle status history</h2><p>Recorded vehicle-level operational status changes</p></div></div>
            <div class="table-scroll">
                <table class="vehicle-detail-table">
                    <thead><tr><th>Previous status</th><th>New status</th><th>Changed at</th><th>Remarks</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $vehicleHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(str_replace('_', ' ', data_get($history, 'previous_status', '—'))); ?></td>
                                <td><span class="vehicle-status-badge is-<?php echo e(\Illuminate\Support\Str::slug(data_get($history, 'new_status', 'unknown'), '_')); ?>"><?php echo e(str_replace('_', ' ', data_get($history, 'new_status', 'Unknown'))); ?></span></td>
                                <td><?php echo e(data_get($history, 'changed_at') ? \Illuminate\Support\Carbon::parse(data_get($history, 'changed_at'))->format('M j, Y g:i A') : 'Time unavailable'); ?></td>
                                <td><?php echo e(data_get($history, 'remarks') ?: '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/vehicles/show.blade.php ENDPATH**/ ?>