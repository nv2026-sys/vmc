<?php $__env->startSection('title', 'Register an emergency'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow">EMERGENCY DESK · INCIDENT INTAKE</span><h1>Register an emergency</h1><p class="muted">Capture caller and incident details. Search recent calls first to help avoid duplicate dispatches.</p></div>
        <a class="button button-light" href="<?php echo e(route('app.jobs')); ?>">Back to incidents</a>
    </div>
    <?php if(session('status')): ?> <div class="success-notice" role="status"><?php echo e(session('status')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?> <div class="alert" role="alert"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    <section class="panel">
        <form class="directory-toolbar" method="GET" action="<?php echo e(route('app.jobs.new')); ?>">
            <div><h2>Caller lookup</h2><p>Search recent incidents by phone number or caller name.</p></div>
            <div class="search-control"><input name="caller_search" value="<?php echo e($callerSearch); ?>" placeholder="Phone number or caller name" aria-label="Search callers"><button class="button button-light button-small" type="submit">Search</button></div>
        </form>
        <?php if($callerSearch !== ''): ?>
            <div class="table-scroll">
                <table>
                    <thead><tr><th>Job ID</th><th>Society / caller / contact</th><th>Emergency</th><th>Status</th><th>Received</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $callerResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a class="text-link" href="<?php echo e(route('app.jobs.show', $candidate->id)); ?>"><?php echo e($candidate->job_id); ?></a></td>
                            <td><strong><?php echo e($candidate->society_name ?: ($candidate->ward?->name ?? 'Area not recorded')); ?></strong><small><?php echo e($candidate->caller_name); ?></small><small><?php echo e($candidate->caller_phone); ?></small></td>
                            <td><?php echo e(str_replace('_', ' ', $candidate->incident_type)); ?><small><?php echo e(str_replace('_', ' ', $candidate->priority)); ?> severity</small></td>
                            <td><span class="status"><?php echo e(str_replace('_', ' ', $candidate->status)); ?></span></td>
                            <td><?php echo e($candidate->occurred_at->format('M j, Y g:i A')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty-cell">No recent caller records found in your authorized station scope.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <p class="muted">Review a matching record before creating a new incident. Only unassigned newly received incidents can be closed as duplicates.</p>
        <?php endif; ?>
    </section>

    <section class="panel">
        <form method="POST" action="<?php echo e(route('app.jobs.store')); ?>" class="managed-user-form incident-form">
            <?php echo csrf_field(); ?>
            <div class="form-grid">
                <label>Caller name<input name="caller_name" value="<?php echo e(old('caller_name')); ?>" required maxlength="255"></label>
                <label>Caller phone<input name="caller_phone" value="<?php echo e(old('caller_phone', $callerSearch)); ?>" required maxlength="32" autocomplete="tel"></label>
                <label>Call source
                    <select name="call_source" required>
                        <?php $__currentLoopData = ['PHONE' => 'Phone', '112' => '112', 'WALK_IN' => 'Walk-in', 'OTHER' => 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('call_source', 'PHONE') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Incident type
                    <select name="incident_type" required>
                        <option value="">Select type</option>
                        <?php $__currentLoopData = ['STRUCTURE_FIRE' => 'Structure fire', 'VEHICLE_FIRE' => 'Vehicle fire', 'ROAD_ACCIDENT' => 'Road accident', 'MEDICAL_EMERGENCY' => 'Medical emergency', 'RESCUE' => 'Rescue', 'OTHER' => 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('incident_type') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Priority
                    <select name="priority" required>
                        <?php $__currentLoopData = ['LOW' => 'Low', 'NORMAL' => 'Normal', 'HIGH' => 'High', 'CRITICAL' => 'Critical']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('priority', 'NORMAL') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Incident time<input type="datetime-local" name="occurred_at" value="<?php echo e(old('occurred_at', now()->format('Y-m-d\\TH:i'))); ?>" required></label>
                <label>Ward / zone
                    <select name="ward_id" required>
                        <option value="">Select ward</option>
                        <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ward->id); ?>" <?php if((string) old('ward_id') === (string) $ward->id): echo 'selected'; endif; ?>><?php echo e($ward->name); ?> · <?php echo e($ward->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Society / area<input name="society_name" value="<?php echo e(old('society_name')); ?>" required maxlength="255" placeholder="Society, neighborhood or landmark"></label>
                <label class="field-wide">Incident address<textarea name="incident_address" required maxlength="2000" rows="3"><?php echo e(old('incident_address')); ?></textarea></label>
                <?php echo $__env->make('incidents.partials.location-picker', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <label class="field-wide">Intake remarks<textarea name="remarks" maxlength="5000" rows="3"><?php echo e(old('remarks')); ?></textarea></label>
            </div>
            <div class="form-actions"><a class="button button-light" href="<?php echo e(route('app.jobs')); ?>">Cancel</a><button class="button button-primary" type="submit">Create incident</button></div>
        </form>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/incidents/create.blade.php ENDPATH**/ ?>