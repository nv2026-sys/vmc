CREATE DATABASE IF NOT EXISTS `emergency_dispatch`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
