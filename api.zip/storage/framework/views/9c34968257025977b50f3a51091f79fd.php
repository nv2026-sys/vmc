

<?php $__env->startSection('title', 'Incident Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $jobStats = [
        ['label' => 'Total incidents', 'value' => $summary['total_jobs'], 'icon' => '!', 'tone' => 'blue'],
        ['label' => 'Total vehicles', 'value' => $summary['vehicles'], 'icon' => '▰', 'tone' => 'cyan'],
        ['label' => 'On Road', 'value' => $summary['on_road_vehicles'], 'icon' => '➤', 'tone' => 'green'],
        ['label' => 'Off Road', 'value' => $summary['off_road_vehicles'], 'icon' => '▣', 'tone' => 'orange'],
        ['label' => 'On Site', 'value' => $summary['on_site_vehicles'], 'icon' => '⌖', 'tone' => 'purple'],
        ['label' => 'Idle / Free', 'value' => $summary['available_vehicles'], 'icon' => '◷', 'tone' => 'blue'],
        ['label' => 'Transfer to 112', 'value' => $summary['transferred_jobs'], 'icon' => '⇄', 'tone' => 'cyan'],
    ];
?>
<section class="ops-dashboard">
    <?php if($preview): ?>
        <div class="notice"><span class="notice-icon">i</span><div><strong>Sign in to view operations</strong><p>Live dashboard data is restricted to authorized accounts.</p></div><a class="button button-primary button-small" href="<?php echo e(route('login')); ?>">Sign in</a></div>
    <?php endif; ?>

    <div class="ops-stat-grid">
        <?php $__currentLoopData = $jobStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="ops-stat-card ops-stat-<?php echo e($stat['tone']); ?>">
                <span class="ops-stat-icon"><?php echo e($stat['icon']); ?></span>
                <div><span><?php echo e($stat['label']); ?></span><strong><?php echo e($preview || $stat['value'] === null ? '—' : number_format($stat['value'])); ?></strong></div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="ops-panel ops-incidents-panel">
        <div class="ops-panel-heading ops-incidents-titlebar">
            <div class="ops-incidents-title-main">
                <div><h2>Recent incidents</h2><p>Latest incidents in your authorized scope</p></div>
                <nav class="ops-incident-filters" aria-label="Filter recent incidents">
                    <?php $__currentLoopData = ['open' => 'Open', 'closed' => 'Closed', 'pending' => 'Pending', 'on_site' => 'On Site', 'en_route' => 'En Route']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('dashboard', array_merge(request()->except(['status_filter', 'incidents_page']), ['status_filter' => $filter]))); ?>" class="ops-incident-filter <?php echo e($incidentFilter === $filter ? 'is-active' : ''); ?>" <?php if($incidentFilter === $filter): ?> aria-current="page" <?php endif; ?>>
                            <?php echo e($label); ?> <span><?php echo e(number_format($incidentFilterCounts[$filter] ?? 0)); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
                <form class="ops-table-search ops-incident-search" method="GET" action="<?php echo e(route('dashboard')); ?>">
                    <input type="hidden" name="status_filter" value="<?php echo e($incidentFilter); ?>">
                    <input type="hidden" name="vehicle_filter" value="<?php echo e($vehicleFilter); ?>">
                    <?php if($mapWardId): ?><input type="hidden" name="map_ward_id" value="<?php echo e($mapWardId); ?>"><?php endif; ?>
                    <?php if(request()->filled('vehicle_search')): ?><input type="hidden" name="vehicle_search" value="<?php echo e($vehicleSearch); ?>"><?php endif; ?>
                    <label class="ops-visually-hidden" for="incident-search">Search incidents</label>
                    <input id="incident-search" type="search" name="incident_search" value="<?php echo e($incidentSearch); ?>" placeholder="Search incident…">
                    <button type="submit" aria-label="Search incidents">⌕</button>
                </form>
            </div>
            <a class="ops-incidents-view-all" href="<?php echo e(route('app.jobs')); ?>">View all incidents <span aria-hidden="true">→</span></a>
        </div>
        <div class="ops-incidents-toolbar">
            <div class="ops-incidents-toolbar-tools">
                <?php if($canViewIncidentMap): ?>
                    <div class="ops-view-toggle" role="group" aria-label="Recent incidents view">
                        <button type="button" class="is-active" data-incident-view="table" aria-pressed="true">Table View</button>
                        <button type="button" data-incident-view="map" aria-pressed="false">Map View</button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="ops-table-wrap ops-incidents-table-wrap" data-incident-view-panel="table">
            <table class="ops-table ops-incidents-table">
                <thead>
                    <tr><th>#</th><th>Priority</th><th>Incident details</th><th>Caller name / phone</th><th>Ward</th><th>Assigned vehicle</th><th>Current status</th><th>Elapsed time</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($assignment = $job->assignments->first()); ?>
                        <tr data-incident-row="<?php echo e($job->job_id); ?>" data-map-incident="<?php echo e($job->job_id); ?>" data-map-ward-id="<?php echo e($job->ward_id); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><span class="ops-incident-priority is-<?php echo e(strtolower($job->priority)); ?>"><?php echo e(str_replace('_', ' ', $job->priority)); ?></span></td>
                            <td>
                                <a class="ops-incident-link" href="<?php echo e(route('app.jobs.show', $job)); ?>"><?php echo e(str_replace('_', ' ', $job->incident_type)); ?></a>
                                <span class="ops-incident-location">
                                    <small><?php echo e($job->incident_address); ?></small>
                                    <?php if(auth()->user()?->hasPermission('gps.view') && auth()->user()?->hasPermission('jobs.view') && $job->latitude !== null && $job->longitude !== null): ?>
                                        <a class="ops-incident-map-link" href="<?php echo e(route('app.tracking', ['incident_id' => $job->id])); ?>" aria-label="Show <?php echo e($job->job_id); ?> location on map" title="Show location on map">
                                            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z"/><circle cx="12" cy="9" r="2.4"/></svg>
                                        </a>
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td><strong><?php echo e($job->caller_name); ?></strong><small><?php echo e($job->caller_phone); ?></small></td>
                            <td><span class="ops-ward-badge <?php echo e($job->ward_id ? 'is-tone-'.($job->ward_id % 5) : 'is-unassigned'); ?>"><?php echo e($job->ward?->name ?? '—'); ?></span></td>
                            <td>
                                <?php if($assignment): ?>
                                    <strong><?php echo e($assignment->vehicle?->vehicle_number ?? '—'); ?></strong>
                                    <small><?php echo e($assignment->fireStation?->name ?? 'Station not set'); ?></small>
                                <?php else: ?>
                                    <span class="ops-muted-value">Unassigned</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="ops-incident-status is-<?php echo e(strtolower($job->status)); ?>"><?php echo e(str_replace('_', ' ', $job->status)); ?></span></td>
                            <td><time datetime="<?php echo e($job->occurred_at->toIso8601String()); ?>"><?php echo e($job->occurred_at->diffForHumans(now(), true)); ?></time></td>
                            <td><a class="ops-incident-action" href="<?php echo e(route('app.jobs.show', $job)); ?>">View <span aria-hidden="true">→</span></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="ops-incidents-empty" colspan="9"><?php echo e($preview ? 'Sign in to view recent incidents.' : 'No incidents match this filter.'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($canViewIncidentMap): ?>
        <div class="ops-incidents-map-view" data-incident-view-panel="map" hidden>
            <link rel="stylesheet" href="<?php echo e(asset('css/dashboard-live-map.css')); ?>?v=<?php echo e(filemtime(public_path('css/dashboard-live-map.css'))); ?>">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
            <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
            <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
            <div class="ops-live-map-toolbar">
                <label class="ops-map-ward-filter">Ward
                    <select data-map-ward-filter>
                        <option value="">All wards</option>
                        <?php $__currentLoopData = $mapWards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ward->id); ?>" <?php if((string) $mapWardId === (string) $ward->id): echo 'selected'; endif; ?>><?php echo e($ward->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label class="ops-map-search">Vehicle
                    <input type="search" data-map-search-vehicle placeholder="Vehicle no.">
                </label>
                <label class="ops-map-search">Incident
                    <input type="search" data-map-search-incident placeholder="Incident ID">
                </label>
                <div class="ops-map-control-group" role="group" aria-label="Map layers and display">
                    <button type="button" data-map-layer="vehicles" aria-pressed="true">Vehicles</button>
                    <button type="button" data-map-layer="incidents" aria-pressed="true">Incidents</button>
                    <button type="button" data-map-layer="density" aria-pressed="true">Density</button>
                    <button type="button" data-map-fullscreen>Fullscreen</button>
                    <button type="button" data-map-satellite disabled title="Satellite imagery provider is not configured">Satellite</button>
                    <button type="button" data-map-boundaries disabled title="Ward boundary data is not available">Ward boundaries</button>
                    <button type="button" data-map-refresh>Refresh map</button>
                </div>
            </div>
            <div class="ops-live-map-shell">
                <div class="ops-live-map" id="ops-live-map" role="application" aria-label="Live vehicle and incident map"
                    data-map-endpoint="<?php echo e(route('dashboard.map-data')); ?>"
                    data-map-payload="<?php echo e(json_encode($liveMapData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)); ?>">
                </div>
                <p class="ops-live-map-message" data-map-message role="status" hidden></p>
            </div>
            <div class="ops-live-map-legend" aria-label="Map legend">
                <span><i class="is-incident-critical"></i> Critical incident</span>
                <span><i class="is-incident-high"></i> High incident</span>
                <span><i class="is-incident-medium"></i> Medium incident</span>
                <span><i class="is-incident-low"></i> Low incident</span>
                <span><i class="is-vehicle-on-road"></i> On Road / Moving</span>
                <span><i class="is-vehicle-off-road"></i> Off Road</span>
                <span><i class="is-vehicle-assigned"></i> Assigned</span>
                <span><i class="is-vehicle-idle"></i> Idle / Free</span>
                <span><i class="is-vehicle-at-incident"></i> At Incident / On Site</span>
                <span><i class="is-density"></i> Ward density from geocoded incidents</span>
            </div>
            <p class="ops-live-map-attribution">Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>. Density circles use the geocoded incidents shown here, not ward boundaries.</p>
            <script defer src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <script defer src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
            <script defer src="<?php echo e(asset('dashboard-live-map.js')); ?>?v=<?php echo e(filemtime(public_path('dashboard-live-map.js'))); ?>"></script>
        </div>
        <?php endif; ?>
        <div class="ops-table-pagination">
            <?php if($recentJobs instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
                <span>Showing <?php echo e($recentJobs->firstItem() ?? 0); ?>–<?php echo e($recentJobs->lastItem() ?? 0); ?> of <?php echo e(number_format($recentJobs->total())); ?> incidents</span>
                <?php echo e($recentJobs->links()); ?>

            <?php else: ?>
                <span><?php echo e($recentJobs->count()); ?> incidents</span>
            <?php endif; ?>
        </div>
    </section>

    <?php if(auth()->user()?->hasPermission('vehicles.view')): ?>
        <section class="ops-panel ops-vehicles-panel">
            <div class="ops-panel-heading">
                <div><h2>Vehicles</h2><p>Fleet readiness and latest known location</p></div>
                <div class="ops-vehicle-header-tools">
                    <nav class="ops-vehicle-tabs" aria-label="Filter vehicles">
                        <?php $__currentLoopData = ['all' => 'All', 'on_road' => 'On Road', 'off_road' => 'Off Road', 'assigned' => 'Assigned', 'idle' => 'Idle', 'at_incident' => 'At Incident']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('dashboard', array_merge(request()->except(['vehicle_filter', 'vehicles_page']), ['vehicle_filter' => $filter]))); ?>" class="ops-vehicle-tab <?php echo e($vehicleFilter === $filter ? 'is-active' : ''); ?>" <?php if($vehicleFilter === $filter): ?> aria-current="page" <?php endif; ?>>
                                <?php echo e($label); ?> <span><?php echo e(number_format($vehicleFilterCounts[$filter] ?? 0)); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                    <form class="ops-table-search" method="GET" action="<?php echo e(route('dashboard')); ?>">
                        <input type="hidden" name="status_filter" value="<?php echo e($incidentFilter); ?>">
                        <input type="hidden" name="vehicle_filter" value="<?php echo e($vehicleFilter); ?>">
                        <?php if($mapWardId): ?><input type="hidden" name="map_ward_id" value="<?php echo e($mapWardId); ?>"><?php endif; ?>
                        <?php if(request()->filled('incident_search')): ?><input type="hidden" name="incident_search" value="<?php echo e($incidentSearch); ?>"><?php endif; ?>
                        <label class="ops-visually-hidden" for="vehicle-search">Search vehicles</label>
                        <input id="vehicle-search" type="search" name="vehicle_search" value="<?php echo e($vehicleSearch); ?>" placeholder="Search vehicle…">
                        <button type="submit" aria-label="Search vehicles">⌕</button>
                    </form>
                </div>
                <a href="<?php echo e(route('app.vehicles')); ?>">View all vehicles →</a>
            </div>
            <div class="ops-table-wrap">
                <table class="ops-table ops-vehicles-table">
                    <thead><tr><th>#</th><th>Vehicle no.</th><th>Status</th><th>Open tickets</th><th>Station</th><th>Last known location</th><th>Last update</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $dashboardVehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php ($gpsLog = $vehicle->latestGpsLog); ?>
                            <?php ($mapAssignment = $vehicle->assignments->first()); ?>
                            <?php ($displayStatus = \App\Services\VehicleDisplayStatus::describe($vehicle, $mapAssignment)); ?>
                            <tr data-vehicle-row="<?php echo e($vehicle->vehicle_number); ?>" data-map-vehicle="<?php echo e($vehicle->vehicle_number); ?>" data-map-ward-id="<?php echo e($mapAssignment?->emergencyJob?->ward_id); ?>">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><strong><?php echo e($vehicle->vehicle_number); ?></strong><small><?php echo e(str_replace('_', ' ', $vehicle->vehicle_type)); ?></small></td>
                                <td><span class="vehicle-status-badge is-<?php echo e($displayStatus['class']); ?>"><?php echo e($displayStatus['label']); ?></span></td>
                                <td>
                                    <?php if(auth()->user()?->hasPermission('jobs.view')): ?>
                                        <a class="vehicle-ticket-count" href="<?php echo e(url('/vehicles/'.$vehicle->id.'#open-assignments')); ?>" aria-label="View <?php echo e($vehicle->open_tickets_count); ?> open tickets for <?php echo e($vehicle->vehicle_number); ?>"><?php echo e(number_format($vehicle->open_tickets_count)); ?></a>
                                    <?php else: ?>
                                        <span class="ops-muted-value">Not permitted</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($vehicle->fireStation?->name ?? '—'); ?></td>
                                <td>
                                    <?php if($gpsLog): ?>
                                        <?php echo e(number_format((float) $gpsLog->latitude, 5)); ?>, <?php echo e(number_format((float) $gpsLog->longitude, 5)); ?>

                                    <?php elseif($vehicle->latitude !== null && $vehicle->longitude !== null): ?>
                                        <?php echo e(number_format((float) $vehicle->latitude, 5)); ?>, <?php echo e(number_format((float) $vehicle->longitude, 5)); ?>

                                    <?php else: ?>
                                        <span class="ops-muted-value">Location unavailable</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($gpsLog): ?>
                                        <time datetime="<?php echo e($gpsLog->recorded_at->toIso8601String()); ?>"><?php echo e($gpsLog->recorded_at->format('M j, H:i')); ?></time>
                                    <?php else: ?>
                                        <span class="ops-muted-value">No GPS update</span>
                                    <?php endif; ?>
                                </td>
                                <td><a class="ops-incident-action" href="<?php echo e(url('/vehicles/'.$vehicle->id)); ?>">View Details <span aria-hidden="true">→</span></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td class="ops-incidents-empty" colspan="8">No vehicles are available in your access scope.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="ops-table-pagination">
                <?php if($dashboardVehicles instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
                    <span>Showing <?php echo e($dashboardVehicles->firstItem() ?? 0); ?>–<?php echo e($dashboardVehicles->lastItem() ?? 0); ?> of <?php echo e(number_format($dashboardVehicles->total())); ?> vehicles</span>
                    <nav class="ops-vehicle-pagination" aria-label="Vehicle pagination">
                        <?php if($dashboardVehicles->onFirstPage()): ?>
                            <span aria-disabled="true" aria-label="Previous page"><span aria-hidden="true">&lsaquo;</span></span>
                        <?php else: ?>
                            <a href="<?php echo e($dashboardVehicles->previousPageUrl()); ?>" rel="prev" aria-label="Previous page"><span aria-hidden="true">&lsaquo;</span></a>
                        <?php endif; ?>
                        <?php if($dashboardVehicles->currentPage() > 2): ?>
                            <a href="<?php echo e($dashboardVehicles->url(1)); ?>">1</a>
                            <?php if($dashboardVehicles->currentPage() > 3): ?><span aria-hidden="true"><span>&hellip;</span></span><?php endif; ?>
                        <?php endif; ?>
                        <?php for($page = max(1, $dashboardVehicles->currentPage() - 1); $page <= min($dashboardVehicles->lastPage(), $dashboardVehicles->currentPage() + 1); $page++): ?>
                            <?php if($page === $dashboardVehicles->currentPage()): ?>
                                <span aria-current="page"><span><?php echo e($page); ?></span></span>
                            <?php else: ?>
                                <a href="<?php echo e($dashboardVehicles->url($page)); ?>" aria-label="Go to page <?php echo e($page); ?>"><?php echo e($page); ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if($dashboardVehicles->currentPage() < $dashboardVehicles->lastPage() - 1): ?>
                            <?php if($dashboardVehicles->currentPage() < $dashboardVehicles->lastPage() - 2): ?><span aria-hidden="true"><span>&hellip;</span></span><?php endif; ?>
                            <a href="<?php echo e($dashboardVehicles->url($dashboardVehicles->lastPage())); ?>"><?php echo e($dashboardVehicles->lastPage()); ?></a>
                        <?php endif; ?>
                        <?php if($dashboardVehicles->hasMorePages()): ?>
                            <a href="<?php echo e($dashboardVehicles->nextPageUrl()); ?>" rel="next" aria-label="Next page"><span aria-hidden="true">&rsaquo;</span></a>
                        <?php else: ?>
                            <span aria-disabled="true" aria-label="Next page"><span aria-hidden="true">&rsaquo;</span></span>
                        <?php endif; ?>
                    </nav>
                <?php else: ?>
                    <span><?php echo e($dashboardVehicles->count()); ?> vehicles</span>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</section>
<script>
(() => {
    const panel = document.querySelector('.ops-incidents-panel');
    if (!panel) return;

    const buttons = panel.querySelectorAll('[data-incident-view]');
    const views = panel.querySelectorAll('[data-incident-view-panel]');
    if (!buttons.length || !views.length) return;

    buttons.forEach((button) => {
        button.addEventListener('click', () => {
            const selectedView = button.dataset.incidentView;

            buttons.forEach((viewButton) => {
                const isSelected = viewButton === button;
                viewButton.classList.toggle('is-active', isSelected);
                viewButton.setAttribute('aria-pressed', String(isSelected));
            });
            views.forEach((view) => {
                view.hidden = view.dataset.incidentViewPanel !== selectedView;
            });
            try {
                localStorage.setItem('vmc-dashboard-map-view', selectedView);
            } catch (error) {
                console.warn('Dashboard map view preference could not be saved.', error);
            }
            if (selectedView === 'map') {
                window.dispatchEvent(new Event('vmc-map-visible'));
            }
        });
    });

    try {
        if (localStorage.getItem('vmc-dashboard-map-view') === 'map') {
            panel.querySelector('[data-incident-view="map"]')?.click();
        }
    } catch (error) {
        console.warn('Dashboard map view preference could not be read.', error);
    }
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>