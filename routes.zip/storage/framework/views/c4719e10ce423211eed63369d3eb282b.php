<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow"><?php echo e(strtoupper($kind === 'roles' ? 'ACCESS CONTROL' : ($kind === 'users' ? 'ADMINISTRATION' : 'FIELD OPERATIONS'))); ?></span><h1><?php echo e($title); ?></h1><p class="muted">Permission-scoped directory of live database records.</p></div>
        <div class="page-heading-actions">
            <?php if($records): ?> <span class="record-count"><strong><?php echo e(number_format($records->total())); ?></strong> records</span> <?php endif; ?>
            <?php if($canManage && in_array($kind, ['stations', 'wards', 'vehicles', 'teams'], true)): ?>
                <a class="button button-primary" href="<?php echo e(route('app.'.$kind.'.create')); ?>">+ Add <?php echo e(strtolower(match ($kind) { 'stations' => 'station', 'wards' => 'ward', 'vehicles' => 'vehicle', default => 'team' })); ?></a>
            <?php endif; ?>
            <?php if($kind === 'jobs' && $canCreate): ?>
                <a class="button button-primary" href="<?php echo e(route('app.jobs.new')); ?>">+ Register incident</a>
            <?php endif; ?>
            <?php if($kind === 'roles' && $canManageRoles): ?>
                <a class="button button-primary" href="<?php echo e(route('app.roles.create')); ?>">+ Add role</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if (! (auth()->user())): ?>
        <div class="notice"><span class="notice-icon">i</span><div><strong>Sign in to load live records.</strong><p>Directory access is restricted to your authorized operational scope.</p></div><a class="button button-light button-small" href="<?php echo e(route('login')); ?>">Sign in →</a></div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="success-notice" role="status"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert" role="alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <section class="panel directory-panel">
        <form class="directory-toolbar" method="GET" action="<?php echo e(url()->current()); ?>">
            <div><h2><?php echo e($title); ?></h2><p>Search authorized records</p></div>
            <div class="search-control"><input name="search" value="<?php echo e($search); ?>" placeholder="Search <?php echo e(strtolower($title)); ?>…" aria-label="Search <?php echo e($title); ?>"><button class="button button-light button-small" type="submit">Search</button></div>
        </form>
        <?php if($records): ?>
            <div class="table-scroll">
                <table>
                    <?php if($kind === 'stations'): ?>
                        <thead><tr><th>Station</th><th>Code</th><th>Coverage</th><th>Team</th><th>Status</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($station->name); ?></strong><small><?php echo e($station->address); ?></small><?php if($canManage): ?><small><a class="text-link" href="<?php echo e(route('app.stations.edit', $station->id)); ?>">Edit</a></small><?php endif; ?></td><td><code><?php echo e($station->code); ?></code></td><td><?php echo e($station->wards_count); ?> wards</td><td><?php echo e($station->active_staff_count); ?> staff</td><td><span class="status <?php echo e($station->is_active ? 'status-active' : 'status-inactive'); ?>"><?php echo e($station->is_active ? 'Active' : 'Inactive'); ?></span></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="5" class="empty-cell">No station records match your search.</td></tr><?php endif; ?></tbody>
                    <?php elseif($kind === 'wards'): ?>
                        <thead><tr><th>Ward</th><th>Code</th><th>Assigned stations</th><th>Status</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($ward->name); ?></strong><small><?php echo e($ward->description ?: 'Coverage area'); ?></small><?php if($canManage): ?><small><a class="text-link" href="<?php echo e(route('app.wards.edit', $ward->id)); ?>">Edit</a></small><?php endif; ?></td><td><code><?php echo e($ward->code); ?></code></td><td><?php echo e($ward->fireStations->pluck('name')->join(', ') ?: 'No station assigned'); ?></td><td><span class="status <?php echo e($ward->is_active ? 'status-active' : 'status-inactive'); ?>"><?php echo e($ward->is_active ? 'Active' : 'Inactive'); ?></span></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="4" class="empty-cell">No ward records match your search.</td></tr><?php endif; ?></tbody>
                    <?php elseif($kind === 'users'): ?>
                        <thead><tr><th>Team member</th><th>Work email</th><th>Access roles</th><th>Status</th><th>Last sign in</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directoryUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($directoryUser->name); ?></strong></td><td><?php echo e($directoryUser->email); ?></td><td><?php echo e($directoryUser->roles->pluck('name')->join(', ') ?: 'No roles assigned'); ?></td><td><span class="status <?php echo e($directoryUser->is_active ? 'status-active' : 'status-inactive'); ?>"><?php echo e($directoryUser->is_active ? 'Active' : 'Inactive'); ?></span></td><td><?php echo e($directoryUser->last_login_at?->format('M j, Y g:i A') ?? 'Never'); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="5" class="empty-cell">No user records match your search.</td></tr><?php endif; ?></tbody>
                    <?php elseif($kind === 'vehicles'): ?>
                        <thead><tr><th>Vehicle</th><th>Type</th><th>Registration</th><th>Station</th><th>Status</th><th>Last service</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($vehicle->vehicle_number); ?></strong><small><?php echo e($vehicle->gps_device_id ?: 'No GPS device registered'); ?></small><?php if($canManage): ?><small><a class="text-link" href="<?php echo e(route('app.vehicles.edit', $vehicle->id)); ?>">Edit</a></small><?php endif; ?></td><td><?php echo e(str_replace('_', ' ', $vehicle->vehicle_type)); ?></td><td><?php echo e($vehicle->registration_number ?: '—'); ?></td><td><?php echo e($vehicle->fireStation?->name ?? 'Unassigned'); ?></td><td><span class="status"><?php echo e(str_replace('_', ' ', $vehicle->status)); ?></span></td><td><?php echo e($vehicle->last_service_at?->format('M j, Y') ?? 'Not recorded'); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="6" class="empty-cell">No vehicle records match your search.</td></tr><?php endif; ?></tbody>
                    <?php elseif($kind === 'teams'): ?>
                        <thead><tr><th>Team</th><th>Station</th><th>Team leader</th><th>Members</th><th>Contact</th><th>Status</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($team->name); ?></strong><?php if($canManage): ?><small><a class="text-link" href="<?php echo e(route('app.teams.edit', $team->id)); ?>">Edit</a></small><?php endif; ?></td><td><?php echo e($team->fireStation?->name ?? 'Unassigned'); ?></td><td><?php echo e($team->leader?->name ?? 'Not assigned'); ?></td><td><?php echo e($team->active_members_count); ?></td><td><?php echo e($team->contact_number ?: '—'); ?></td><td><span class="status"><?php echo e(str_replace('_', ' ', $team->status)); ?></span></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="6" class="empty-cell">No team records match your search.</td></tr><?php endif; ?></tbody>
                    <?php elseif($kind === 'jobs'): ?>
                        <thead><tr><th>Job ID</th><th>Society / caller / contact</th><th>Emergency</th><th>Severity</th><th>Status</th><th>Received</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><a class="text-link" href="<?php echo e(route('app.jobs.show', $job->id)); ?>"><?php echo e($job->job_id); ?></a></strong><small><?php echo e($job->ward?->code ?? 'Location'); ?></small></td><td><strong><?php echo e($job->society_name ?: ($job->ward?->name ?? 'Area not recorded')); ?></strong><small><?php echo e($job->caller_name); ?></small><small><?php echo e($job->caller_phone); ?></small></td><td><?php echo e(str_replace('_', ' ', $job->incident_type)); ?><small><?php echo e($job->incident_address); ?></small></td><td><span class="status"><?php echo e(str_replace('_', ' ', $job->priority)); ?></span></td><td><span class="status"><?php echo e(str_replace('_', ' ', $job->status)); ?></span></td><td><?php echo e($job->occurred_at->format('M j, Y g:i A')); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="6" class="empty-cell">No incident records match your search.</td></tr><?php endif; ?></tbody>
                    <?php else: ?>
                        <thead><tr><th>Role</th><th>Code</th><th>Description</th><th>Permissions</th><th>Type</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><strong><?php echo e($role->name); ?></strong></td><td><code><?php echo e($role->code); ?></code></td><td><?php echo e($role->description); ?></td><td><?php echo e($role->permissions->pluck('code')->join(', ') ?: 'No permissions assigned'); ?></td><td><?php echo e($role->is_system ? 'System role' : 'Custom role'); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="5" class="empty-cell">No role records match your search.</td></tr><?php endif; ?></tbody>
                    <?php endif; ?>
                </table>
            </div>
            <div class="pagination"><?php echo e($records->links()); ?></div>
        <?php else: ?>
            <div class="empty-state directory-empty"><span class="empty-icon">⌕</span><strong>Live records are protected</strong><p>Sign in to search this directory within your access scope.</p></div>
        <?php endif; ?>
    </section>
    <p class="privacy-note">✓ &nbsp;This directory enforces server-side permissions and station-level access restrictions.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/pages/catalog.blade.php ENDPATH**/ ?>