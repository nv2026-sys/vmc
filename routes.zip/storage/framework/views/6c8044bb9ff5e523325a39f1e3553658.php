

<?php $__env->startSection('title', 'Add role'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div><span class="eyebrow">ACCESS CONTROL</span><h1>Add role</h1><p class="muted">Create a custom role and choose its permissions.</p></div>
    </div>
    <section class="form-panel panel">
        <form method="POST" action="<?php echo e(route('app.roles.store')); ?>" class="managed-user-form">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
                <div class="alert" role="alert"><strong>Check the form:</strong> <?php echo e($errors->first()); ?></div>
            <?php endif; ?>
            <div class="form-grid">
                <div class="field">
                    <label for="name">Role name</label>
                    <input id="name" name="name" value="<?php echo e(old('name')); ?>" maxlength="255" required>
                </div>
                <div class="field">
                    <label for="code">Role code</label>
                    <input id="code" name="code" value="<?php echo e(old('code')); ?>" maxlength="64" pattern="[A-Z][A-Z0-9_]*" placeholder="EXAMPLE_ROLE" required>
                    <small>Use uppercase letters, numbers, and underscores.</small>
                </div>
                <div class="field field-wide">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" maxlength="2000" rows="3"><?php echo e(old('description')); ?></textarea>
                </div>
            </div>

            <fieldset class="station-fieldset">
                <legend>Permissions <span>Select only the access this role needs.</span></legend>
                <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['permissions.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="station-choice-grid">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="station-choice">
                            <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if(in_array((string) $permission->id, old('permissions', []), true)): echo 'checked'; endif; ?>>
                            <span><strong><?php echo e($permission->name); ?></strong><small><?php echo e($permission->code); ?></small></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </fieldset>

            <div class="form-actions">
                <a class="button button-light" href="<?php echo e(route('app.roles')); ?>">Cancel</a>
                <button class="button button-primary" type="submit">Create role</button>
            </div>
        </form>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/roles/create.blade.php ENDPATH**/ ?>