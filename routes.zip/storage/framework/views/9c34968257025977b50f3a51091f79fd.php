<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $jobStats = [
        ['label' => 'Total calls', 'value' => $summary['total_jobs'], 'icon' => '☎', 'tone' => 'blue'],
        ['label' => 'Pending', 'value' => $summary['pending_jobs'], 'icon' => '◷', 'tone' => 'orange'],
        ['label' => 'Active', 'value' => $summary['active_jobs'], 'icon' => '➤', 'tone' => 'green'],
        ['label' => 'Completed', 'value' => $summary['completed_jobs'], 'icon' => '✓', 'tone' => 'purple'],
        ['label' => 'Transfer to 112', 'value' => $summary['transferred_jobs'], 'icon' => '⇄', 'tone' => 'cyan'],
    ];
?>
<section class="ops-dashboard">
    <div class="ops-page-heading">
        <div><span class="ops-page-kicker">FIRE CONTROL ROOM · VADODARA</span><h1>Operations overview</h1><p>Incident activity, station readiness and response coordination.</p></div>
    </div>

    <?php if($preview): ?>
        <div class="notice"><span class="notice-icon">i</span><div><strong>Sign in to view operations</strong><p>Live dashboard data is restricted to authorized accounts.</p></div><a class="button button-primary button-small" href="<?php echo e(route('login')); ?>">Sign in</a></div>
    <?php endif; ?>

    <div class="ops-stat-grid">
        <?php $__currentLoopData = $jobStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="ops-stat-card ops-stat-<?php echo e($stat['tone']); ?>">
                <span class="ops-stat-icon"><?php echo e($stat['icon']); ?></span>
                <div><span><?php echo e($stat['label']); ?></span><strong><?php echo e($preview || $stat['value'] === null ? '—' : number_format($stat['value'])); ?></strong></div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="ops-panel ops-recent-panel">
        <div class="ops-panel-heading"><div><h2>Incoming calls &amp; new jobs</h2><p>Automatically rotating · updates every 15 seconds</p></div><a href="<?php echo e(route('app.jobs')); ?>">View all →</a></div>
        <div class="ops-activity-carousel" data-activity-carousel data-feed-url="<?php echo e(route('dashboard.activity')); ?>" aria-label="Recent incoming calls and new jobs" aria-roledescription="carousel">
            <p class="ops-activity-refresh-status" data-activity-status role="status" aria-live="polite" hidden></p>
            <div class="ops-activity-slides" data-activity-slides aria-live="polite">
                <?php $__empty_1 = true; $__currentLoopData = $activityItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="ops-activity-slide" data-activity-item="<?php echo e($item['key']); ?>" href="<?php echo e($item['url']); ?>" <?php if(!$loop->first): ?> hidden <?php endif; ?>>
                        <div class="ops-activity-topline"><span class="ops-activity-kind <?php echo e($item['type'] === 'NEW CALL' ? 'is-call' : 'is-job'); ?>"><?php echo e($item['type']); ?></span><time datetime="<?php echo e($item['time']); ?>"><?php echo e(\Illuminate\Support\Carbon::parse($item['time'])->format('M j · H:i:s')); ?></time></div>
                        <strong class="ops-activity-job"><?php echo e($item['job_id']); ?></strong>
                        <span class="ops-activity-caller"><?php echo e($item['society']); ?> · <?php echo e($item['caller']); ?> · <?php echo e($item['phone']); ?></span>
                        <span class="ops-activity-description"><?php echo e($item['incident']); ?> · <?php echo e(str_replace('_', ' ', $item['priority'])); ?> severity</span>
                        <span class="ops-activity-status"><?php echo e($item['status']); ?></span>
                        <?php if(!empty($item['remarks'])): ?><span class="ops-activity-remarks"><?php echo e($item['remarks']); ?></span><?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="ops-empty" data-activity-empty><?php echo e($preview ? 'Sign in to view incoming calls.' : 'No recent calls or jobs in your access scope.'); ?></p>
                <?php endif; ?>
            </div>
            <div class="ops-activity-controls" data-activity-controls <?php if($activityItems->isEmpty()): ?> hidden <?php endif; ?>>
                <button class="ops-activity-arrow" type="button" data-activity-previous aria-label="Previous activity">‹</button>
                <span data-activity-count aria-live="polite"><?php echo e($activityItems->isEmpty() ? '0 / 0' : '1 / '.$activityItems->count()); ?></span>
                <button class="ops-activity-arrow" type="button" data-activity-next aria-label="Next activity">›</button>
            </div>
        </div>
    </section>

    <div class="ops-primary-grid">
        <section class="ops-panel ops-map-panel">
            <div class="ops-panel-heading">
                <div><h2><span class="ops-pin">⌖</span> Incident &amp; station map</h2><p>Saved coordinates · Schematic view, not live GPS</p></div>
                <?php if(auth()->user()?->hasPermission('gps.view')): ?>
                    <a class="ops-map-action" href="<?php echo e(route('app.tracking')); ?>">Open live tracking <span aria-hidden="true">→</span></a>
                <?php endif; ?>
                <div class="ops-map-legend"><span><i class="legend-fire"></i> Incident</span><span><i class="legend-station"></i> Station</span><span><i class="legend-unit"></i> Vehicle</span></div>
            </div>
            <div class="ops-map" role="group" aria-label="Schematic map of saved station, incident and vehicle coordinates">
                <div class="map-park map-park-one"></div><div class="map-park map-park-two"></div>
                <div class="map-river"></div>
                <span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-road road-three"></span>
                <span class="map-road road-four"></span><span class="map-road road-five"></span><span class="map-road road-six"></span>
                <span class="map-road road-seven"></span><span class="map-road road-eight"></span><span class="map-road road-nine"></span>
                <div class="map-city-label">Vadodara</div>
                <?php $__empty_1 = true; $__currentLoopData = $mapMarkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="map-marker map-marker-<?php echo e($marker['kind']); ?>" style="left: <?php echo e($marker['x']); ?>%; top: <?php echo e($marker['y']); ?>%" title="<?php echo e(ucfirst($marker['kind'])); ?>: <?php echo e($marker['label']); ?>" role="img" aria-label="<?php echo e(ucfirst($marker['kind'])); ?>: <?php echo e($marker['label']); ?>">
                        <?php echo e($marker['kind'] === 'incident' ? '!' : ($marker['kind'] === 'station' ? '⌂' : '▰')); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="map-empty" role="status"><?php echo e($preview ? 'Sign in to view authorized locations' : 'No coordinates are available in your access scope'); ?></div>
                <?php endif; ?>
                <span class="map-scale">Schematic view · Not live GPS</span>
            </div>
        </section>

        <div class="ops-side-stack">
            <section class="ops-panel ops-station-panel">
                <div class="ops-panel-heading"><div><h2>Fire station availability</h2><p>Stations in your authorized scope</p></div><a href="<?php echo e(route('app.stations')); ?>">View all →</a></div>
                <?php if($stations->isEmpty()): ?>
                    <p class="ops-empty"><?php echo e($preview ? 'Sign in to view station status.' : 'No stations are assigned to your account.'); ?></p>
                <?php else: ?>
                    <div class="ops-station-list">
                        <?php $__currentLoopData = $stations->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ops-station-row">
                                <span class="station-state <?php echo e($station->is_active ? 'is-online' : 'is-offline'); ?>"></span>
                                <span class="ops-station-name"><strong><?php echo e($station->name); ?></strong><small><?php echo e($station->code); ?></small></span>
                                <span class="ops-station-metric"><small>Available</small><strong><?php echo e(isset($station->available_vehicles_count) ? $station->available_vehicles_count : '—'); ?></strong></span>
                                <span class="ops-station-metric"><small>Teams</small><strong><?php echo e(isset($station->active_teams_count) ? $station->active_teams_count : '—'); ?></strong></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>

    <div class="ops-secondary-grid">
        <section class="ops-panel">
            <div class="ops-panel-heading"><div><h2>Ward-wise pending jobs</h2><p>Incident counts by covered ward</p></div><a href="<?php echo e(route('app.jobs')); ?>">View incidents →</a></div>
            <?php if($wardStats->isEmpty()): ?>
                <p class="ops-empty"><?php echo e($preview ? 'Sign in to view ward activity.' : 'No ward activity is available.'); ?></p>
            <?php else: ?>
                <div class="ops-table-wrap">
                    <table class="ops-table">
                        <thead><tr><th>Ward</th><th>Pending</th><th>Active</th><th>Total</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $wardStats->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><strong><?php echo e($item['ward']->name); ?></strong><small><?php echo e($item['ward']->code); ?></small></td><td><?php echo e($item['pending']); ?></td><td><?php echo e($item['active']); ?></td><td><?php echo e($item['pending'] + $item['active']); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            <div class="ops-total-strip"><span>Pending calls</span><strong><?php echo e($preview || $summary['pending_jobs'] === null ? '—' : number_format($summary['pending_jobs'])); ?></strong></div>
        </section>

        <section class="ops-panel ops-job-detail">
            <div class="ops-panel-heading"><div><h2>Incident details</h2><p><?php echo e($selectedJob?->job_id ?? 'Selected incident'); ?></p></div>
                <?php if($selectedJob): ?><span class="ops-priority"><?php echo e(str_replace('_', ' ', $selectedJob->priority)); ?> priority</span><?php endif; ?>
            </div>
            <?php if(!$selectedJob): ?>
                <p class="ops-empty"><?php echo e($preview ? 'Sign in to view incident details.' : 'No incident is available in your scope.'); ?></p>
            <?php else: ?>
                <div class="ops-job-facts">
                    <div><span>Caller</span><strong><?php echo e($selectedJob->caller_name); ?></strong></div>
                    <div><span>Phone</span><strong><?php echo e($selectedJob->caller_phone); ?></strong></div>
                    <div><span>Location</span><strong><?php echo e($selectedJob->incident_address); ?></strong></div>
                    <div><span>Ward</span><strong><?php echo e($selectedJob->ward?->name ?? 'Not assigned'); ?></strong></div>
                    <div><span>Incident</span><strong><?php echo e(str_replace('_', ' ', $selectedJob->incident_type)); ?></strong></div>
                    <div><span>Status</span><strong><?php echo e(str_replace('_', ' ', $selectedJob->status)); ?></strong></div>
                </div>
                <div class="ops-assignment-list">
                    <?php $__empty_1 = true; $__currentLoopData = $selectedJob->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div><span class="assignment-check">✓</span><strong><?php echo e($assignment->fireStation?->name ?? 'Station'); ?></strong><span><?php echo e($assignment->vehicle?->vehicle_number ?? 'No vehicle'); ?><?php echo e($assignment->team ? ' · '.$assignment->team->name : ''); ?></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="assignment-unassigned">No response unit assigned</div>
                    <?php endif; ?>
                </div>
                <div class="ops-timeline">
                    <?php $__currentLoopData = $selectedJob->statusHistory->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><span class="timeline-dot"></span><strong><?php echo e(str_replace('_', ' ', $event->new_status)); ?></strong><time><?php echo e($event->changed_at->format('H:i')); ?></time></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="ops-panel ops-quick-panel">
            <div class="ops-panel-heading"><div><h2>Quick access</h2><p>Open operational master data</p></div></div>
            <div class="ops-quick-grid">
                <?php if(auth()->user()?->hasPermission('jobs.view')): ?>
                    <a href="<?php echo e(route('app.jobs')); ?>"><span>☷</span>Incidents</a>
                <?php endif; ?>
                <?php if(auth()->user()?->hasPermission('vehicles.view')): ?>
                    <a href="<?php echo e(route('app.vehicles')); ?>"><span>▰</span>Vehicles</a>
                <?php endif; ?>
                <?php if(auth()->user()?->hasPermission('teams.view')): ?>
                    <a href="<?php echo e(route('app.teams')); ?>"><span>♧</span>Teams</a>
                <?php endif; ?>
                <?php if(auth()->user()?->hasPermission('stations.view')): ?>
                    <a href="<?php echo e(route('app.stations')); ?>"><span>⌂</span>Stations</a>
                <?php endif; ?>
                <?php if(auth()->user()?->hasPermission('wards.view')): ?>
                    <a href="<?php echo e(route('app.wards')); ?>"><span>◎</span>Wards</a>
                <?php endif; ?>
                <?php if($preview): ?>
                    <a href="<?php echo e(route('login')); ?>"><span>↪</span>Sign in</a>
                <?php endif; ?>
            </div>
        </section>
    </div>
    <footer class="ops-footer"><span><i></i> VMC Emergency Response</span><span>Dashboard data is permission- and station-scoped · Demo records are illustrative</span>
        <?php if(auth()->user()?->hasPermission('vehicles.view')): ?><a href="<?php echo e(route('app.vehicles')); ?>">Vehicle directory →</a><?php endif; ?>
    </footer>
</section>
<?php if($canViewJobs): ?>
<script>
(() => {
    const carousel = document.querySelector('[data-activity-carousel]');
    if (!carousel) return;

    const slides = carousel.querySelector('[data-activity-slides]');
    const controls = carousel.querySelector('[data-activity-controls]');
    const count = carousel.querySelector('[data-activity-count]');
    const status = carousel.querySelector('[data-activity-status]');
    let items = [...slides.querySelectorAll('[data-activity-item]')];
    let current = 0;
    let isRefreshing = false;

    const show = (index) => {
        if (!items.length) return;
        current = (index + items.length) % items.length;
        items.forEach((item, itemIndex) => { item.hidden = itemIndex !== current; });
        controls.hidden = items.length < 2;
        count.textContent = `${current + 1} / ${items.length}`;
    };

    const makeSlide = (activity) => {
        const link = document.createElement('a');
        link.className = 'ops-activity-slide';
        link.dataset.activityItem = activity.key;
        link.href = activity.url;

        const top = document.createElement('div');
        top.className = 'ops-activity-topline';
        const kind = document.createElement('span');
        kind.className = `ops-activity-kind ${activity.type === 'NEW CALL' ? 'is-call' : 'is-job'}`;
        kind.textContent = activity.type;
        const time = document.createElement('time');
        time.dateTime = activity.time;
        time.textContent = new Date(activity.time).toLocaleString([], {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'});
        top.append(kind, time);

        const fields = [
            ['strong', 'ops-activity-job', activity.job_id],
            ['span', 'ops-activity-caller', `${activity.society} · ${activity.caller} · ${activity.phone}`],
            ['span', 'ops-activity-description', `${activity.incident} · ${activity.priority.replaceAll('_', ' ')} severity`],
            ['span', 'ops-activity-status', activity.status],
        ];
        link.append(top);
        fields.forEach(([tag, className, value]) => {
            const element = document.createElement(tag);
            element.className = className;
            element.textContent = value;
            link.append(element);
        });
        if (activity.remarks) {
            const remarks = document.createElement('span');
            remarks.className = 'ops-activity-remarks';
            remarks.textContent = activity.remarks;
            link.append(remarks);
        }
        return link;
    };

    const refresh = async () => {
        if (isRefreshing) return;
        isRefreshing = true;
        status.textContent = 'Refreshing recent activity…';
        status.hidden = false;
        carousel.setAttribute('aria-busy', 'true');
        try {
            const response = await fetch(carousel.dataset.feedUrl, {headers: {'Accept': 'application/json'}, credentials: 'same-origin'});
            if (!response.ok) throw new Error(`Activity refresh failed: ${response.status}`);
            const payload = await response.json();
            const activeKey = items[current]?.dataset.activityItem;
            items = payload.data.map(makeSlide);
            slides.replaceChildren(...items);

            if (!items.length) {
                const empty = document.createElement('p');
                empty.className = 'ops-empty';
                empty.textContent = 'No recent calls or jobs in your access scope.';
                slides.append(empty);
                controls.hidden = true;
                status.hidden = true;
                return;
            }

            const activeIndex = items.findIndex((item) => item.dataset.activityItem === activeKey);
            show(activeIndex >= 0 ? activeIndex : 0);
            status.hidden = true;
        } finally {
            isRefreshing = false;
            carousel.setAttribute('aria-busy', 'false');
        }
    };

    const reportRefreshError = (error) => {
        status.textContent = 'Live updates are unavailable. Showing the most recent activity.';
        status.hidden = false;
        console.error(error);
    };

    carousel.querySelector('[data-activity-previous]').addEventListener('click', () => show(current - 1));
    carousel.querySelector('[data-activity-next]').addEventListener('click', () => show(current + 1));
    show(0);
    refresh().catch(reportRefreshError);

    window.setInterval(() => {
        if (document.visibilityState === 'visible' && !carousel.matches(':hover') && !carousel.contains(document.activeElement)) {
            show(current + 1);
        }
    }, 6000);
    window.setInterval(() => {
        if (document.visibilityState === 'visible') {
            refresh().catch(reportRefreshError);
        }
    }, 15000);
})();
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>