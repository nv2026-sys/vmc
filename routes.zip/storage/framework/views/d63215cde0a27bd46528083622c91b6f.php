<?php $__env->startSection('title', 'Live GPS tracking'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack tracking-page">
    <div class="page-heading">
        <div>
            <span class="eyebrow">FIELD OPERATIONS · LIVE FLEET</span>
            <h1>Live GPS tracking</h1>
            <p class="muted">Authenticated vehicle locations and assignment route history. Positions stay within your station access.</p>
        </div>
        <span class="tracking-live"><i></i> GPS feed</span>
    </div>

    <section class="tracking-layout">
        <div class="panel tracking-map-panel">
            <div class="tracking-panel-heading">
                <div><h2>Fleet location map</h2><p>Local coordinate plot · no third-party map service · refreshed at <?php echo e(now()->format('g:i:s A')); ?></p></div>
                <span class="tracking-count"><?php echo e($vehicles->count()); ?> tracked <?php echo e(\Illuminate\Support\Str::plural('vehicle', $vehicles->count())); ?></span>
            </div>
            <?php if($vehicles->isNotEmpty()): ?>
                <div class="tracking-map">
                    <svg viewBox="0 0 800 480" role="img" aria-label="Map plot of latest vehicle GPS points and selected route">
                        <defs>
                            <pattern id="tracking-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(154,184,218,.12)" stroke-width="1"/>
                            </pattern>
                        </defs>
                        <rect width="800" height="480" fill="url(#tracking-grid)"/>
                        <path d="M0 400 C150 330 190 420 340 350 S600 315 800 205" class="tracking-road"/>
                        <path d="M110 0 C155 115 205 240 350 480" class="tracking-road tracking-road-secondary"/>
                        <?php if($routePoints->count() > 1): ?>
                            <polyline points="<?php echo e($routePath); ?>" class="tracking-route-line"/>
                        <?php endif; ?>
                        <?php $__currentLoopData = $markers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <g class="<?php echo e($marker['is_selected'] ? 'tracking-marker is-selected' : 'tracking-marker'); ?>">
                                <circle cx="<?php echo e($marker['x']); ?>" cy="<?php echo e($marker['y']); ?>" r="13" class="tracking-marker-halo"/>
                                <circle cx="<?php echo e($marker['x']); ?>" cy="<?php echo e($marker['y']); ?>" r="6" class="tracking-marker-dot"/>
                                <text x="<?php echo e($marker['x'] + 12); ?>" y="<?php echo e($marker['y'] - 9); ?>"><?php echo e($marker['vehicle']->vehicle_number); ?></text>
                                <title><?php echo e($marker['vehicle']->vehicle_number); ?> · <?php echo e($marker['vehicle']->latestGpsLog->latitude); ?>, <?php echo e($marker['vehicle']->latestGpsLog->longitude); ?></title>
                            </g>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $routePoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <circle cx="<?php echo e($point['x']); ?>" cy="<?php echo e($point['y']); ?>" r="<?php echo e($loop->first || $loop->last ? 6 : 3.5); ?>" class="<?php echo e($loop->first ? 'tracking-route-point route-start' : ($loop->last ? 'tracking-route-point route-end' : 'tracking-route-point')); ?>">
                                <title><?php echo e($point['log']->recorded_at->format('M j, g:i:s A')); ?> · <?php echo e($point['log']->latitude); ?>, <?php echo e($point['log']->longitude); ?></title>
                            </circle>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </svg>
                    <div class="tracking-map-legend"><span><i class="legend-live"></i> Latest location</span><span><i class="legend-route"></i> Selected route</span></div>
                </div>
            <?php else: ?>
                <div class="tracking-empty"><span>⌖</span><strong>No GPS points received</strong><p>Vehicle positions will appear here after the first authenticated mobile GPS update.</p></div>
            <?php endif; ?>
        </div>

        <aside class="panel tracking-units-panel">
            <div class="tracking-panel-heading"><div><h2>Tracked vehicles</h2><p>Most recent received location</p></div></div>
            <?php if($vehicles->isNotEmpty()): ?>
                <div class="tracking-unit-list">
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isStale = $vehicle->latestGpsLog->recorded_at->lt(now()->subMinutes(5));
                            $activeAssignment = $vehicle->assignments->first();
                        ?>
                        <a class="tracking-unit <?php echo e($selectedVehicle?->is($vehicle) ? 'is-selected' : ''); ?>" href="<?php echo e(route('app.tracking', ['vehicle_id' => $vehicle->id])); ?>">
                            <span class="tracking-unit-icon">⌖</span>
                            <span class="tracking-unit-details">
                                <strong><?php echo e($vehicle->vehicle_number); ?></strong>
                                <small><?php echo e($vehicle->fireStation?->name ?? 'Station unavailable'); ?> · <?php echo e($vehicle->status); ?></small>
                                <?php if($activeAssignment?->emergencyJob): ?>
                                    <small><?php echo e($activeAssignment->emergencyJob->job_id); ?> · <?php echo e(str_replace('_', ' ', $activeAssignment->status)); ?></small>
                                <?php endif; ?>
                            </span>
                            <span class="tracking-unit-time <?php echo e($isStale ? 'is-stale' : ''); ?>"><?php echo e($isStale ? 'STALE' : 'LIVE'); ?><small><?php echo e($vehicle->latestGpsLog->recorded_at->diffForHumans()); ?></small></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="tracking-no-units">No vehicles in your authorized tracking scope.</p>
            <?php endif; ?>
        </aside>
    </section>

    <?php if($selectedVehicle): ?>
        <section class="panel tracking-history-panel">
            <div class="tracking-panel-heading">
                <div><h2>Route history · <?php echo e($selectedVehicle->vehicle_number); ?></h2><p><?php echo e($selectedVehicle->fireStation?->name); ?> · <?php echo e($routePoints->count()); ?> GPS points in this range</p></div>
                <form method="GET" action="<?php echo e(route('app.tracking')); ?>" class="tracking-filters">
                    <input type="hidden" name="vehicle_id" value="<?php echo e($selectedVehicle->id); ?>">
                    <label>Assignment
                        <select name="assignment_id">
                            <option value="">All my vehicle routes</option>
                            <?php $__currentLoopData = $routeAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($assignment->id); ?>" <?php if((string) ($filters['assignment_id'] ?? '') === (string) $assignment->id): echo 'selected'; endif; ?>><?php echo e($assignment->emergencyJob?->job_id ?? 'Job '.$assignment->emergency_job_id); ?> · <?php echo e(str_replace('_', ' ', $assignment->status)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>From<input type="datetime-local" name="from" value="<?php echo e(isset($filters['from']) ? \Illuminate\Support\Carbon::parse($filters['from'])->format('Y-m-d\\TH:i') : now()->subDay()->format('Y-m-d\\TH:i')); ?>"></label>
                    <label>To<input type="datetime-local" name="to" value="<?php echo e(isset($filters['to']) ? \Illuminate\Support\Carbon::parse($filters['to'])->format('Y-m-d\\TH:i') : now()->format('Y-m-d\\TH:i')); ?>"></label>
                    <button class="button button-light button-small" type="submit">Show route</button>
                </form>
            </div>
            <div class="table-scroll"><table><thead><tr><th>Recorded</th><th>Coordinates</th><th>Speed</th><th>Job</th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $routePoints->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($point['log']->recorded_at->format('M j, Y g:i:s A')); ?></td>
                        <td><?php echo e($point['log']->latitude); ?>, <?php echo e($point['log']->longitude); ?></td>
                        <td><?php echo e($point['log']->speed_kph !== null ? $point['log']->speed_kph.' km/h' : '—'); ?></td>
                        <td><?php echo e($point['log']->assignment?->emergencyJob?->job_id ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="empty-cell">No route points match this vehicle and time range.</td></tr>
                <?php endif; ?>
            </tbody></table></div>
        </section>
    <?php endif; ?>
</section>
<script>
    window.setTimeout(() => window.location.reload(), 30000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/tracking/index.blade.php ENDPATH**/ ?>