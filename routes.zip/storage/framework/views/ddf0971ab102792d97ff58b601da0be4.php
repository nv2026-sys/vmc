<?php $__env->startSection('title', 'Reports & analytics'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $summary = $report['summary'];
    $maxDaily = max(1, collect($report['daily'])->max('count'));
    $chartSets = [
        ['title' => 'Incident status', 'items' => $report['statuses'], 'tone' => 'blue'],
        ['title' => 'Severity', 'items' => $report['priorities'], 'tone' => 'severity'],
        ['title' => 'Incident type', 'items' => $report['incident_types'], 'tone' => 'green'],
    ];
?>
<section class="page-stack operations-reports">
    <div class="page-heading">
        <div>
            <span class="eyebrow">INSIGHTS · OPERATIONAL PERFORMANCE</span>
            <h1>Reports &amp; analytics</h1>
            <p class="muted">Operational volumes, severity, deployment activity, and response-time indicators for the selected period.</p>
        </div>
        <div class="report-heading-actions">
            <?php if(auth()->user()->hasPermission('reports.export')): ?>
                <div class="report-export-actions" aria-label="Export report">
                    <?php $__currentLoopData = ['csv' => 'CSV', 'xlsx' => 'Excel', 'pdf' => 'PDF']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $format => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="button button-light" href="<?php echo e(route('app.reports.export', ['format' => $format] + request()->query())); ?>"><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <span class="report-period"><?php echo e(\Illuminate\Support\Carbon::parse($report['filters']['from'])->format('M j')); ?> – <?php echo e(\Illuminate\Support\Carbon::parse($report['filters']['to'])->format('M j, Y')); ?></span>
        </div>
    </div>
    <?php if($errors->any()): ?> <div class="alert" role="alert"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    <form method="GET" action="<?php echo e(route('app.reports')); ?>" class="panel report-filter-form">
        <label>From date<input type="date" name="from" value="<?php echo e($report['filters']['from']); ?>" required></label>
        <label>To date<input type="date" name="to" value="<?php echo e($report['filters']['to']); ?>" required></label>
        <label>Station
            <select name="station_id">
                <option value="">All accessible stations</option>
                <?php $__currentLoopData = $report['stations_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($station['id']); ?>" <?php if($report['filters']['station_id'] === $station['id']): echo 'selected'; endif; ?>><?php echo e($station['name']); ?> · <?php echo e($station['code']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <button class="button button-primary" type="submit">Apply filters</button>
    </form>

    <div class="report-stat-grid">
        <article class="report-stat-card"><span class="report-stat-icon tone-blue">☎</span><div><small>Total incidents</small><strong><?php echo e(number_format($summary['total_jobs'])); ?></strong></div></article>
        <article class="report-stat-card"><span class="report-stat-icon tone-orange">◷</span><div><small>Pending</small><strong><?php echo e(number_format($summary['pending_jobs'])); ?></strong></div></article>
        <article class="report-stat-card"><span class="report-stat-icon tone-green">➤</span><div><small>Active</small><strong><?php echo e(number_format($summary['active_jobs'])); ?></strong></div></article>
        <article class="report-stat-card"><span class="report-stat-icon tone-purple">✓</span><div><small>Completed · <?php echo e($summary['completion_rate']); ?>%</small><strong><?php echo e(number_format($summary['completed_jobs'])); ?></strong></div></article>
        <article class="report-stat-card"><span class="report-stat-icon tone-red">!</span><div><small>Critical priority</small><strong><?php echo e(number_format($summary['critical_jobs'])); ?></strong></div></article>
        <article class="report-stat-card"><span class="report-stat-icon tone-cyan">⇄</span><div><small>112 transfers</small><strong><?php echo e(number_format($summary['transferred_jobs'])); ?></strong></div></article>
    </div>

    <section class="panel report-trend-panel">
        <div class="report-panel-heading"><div><h2>Daily incident volume</h2><p><?php echo e(count($report['daily'])); ?> days · based on incident-reported time</p></div><strong><?php echo e(number_format($summary['total_jobs'])); ?> incidents</strong></div>
        <?php if($summary['total_jobs'] > 0): ?>
            <div class="report-trend-chart" role="img" aria-label="Daily incident count from <?php echo e($report['filters']['from']); ?> to <?php echo e($report['filters']['to']); ?>">
                <?php $__currentLoopData = $report['daily']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="report-trend-day" title="<?php echo e($day['label']); ?>: <?php echo e($day['count']); ?> incidents">
                        <span class="report-trend-value"><?php echo e($day['count'] ?: ''); ?></span>
                        <span class="report-trend-bar" style="height: <?php echo e(max(3, ($day['count'] / $maxDaily) * 100)); ?>%"></span>
                        <small><?php echo e(\Illuminate\Support\Carbon::parse($day['date'])->format('j')); ?></small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="report-trend-axis"><span><?php echo e(\Illuminate\Support\Carbon::parse($report['filters']['from'])->format('M j')); ?></span><span><?php echo e(\Illuminate\Support\Carbon::parse($report['filters']['to'])->format('M j')); ?></span></div>
        <?php else: ?>
            <p class="report-empty">No incidents were recorded for this reporting period.</p>
        <?php endif; ?>
    </section>

    <section class="report-breakdown-grid">
        <?php $__currentLoopData = $chartSets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $maxCount = max(1, collect($set['items'])->max('count')); ?>
            <article class="panel report-breakdown">
                <div class="report-panel-heading"><div><h2><?php echo e($set['title']); ?></h2><p>Share of reported incidents</p></div></div>
                <?php if(count($set['items'])): ?>
                    <div class="report-bars">
                        <?php $__currentLoopData = $set['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="report-bar-row">
                                <div class="report-bar-label"><span><?php echo e(str_replace('_', ' ', $item['label'])); ?></span><strong><?php echo e(number_format($item['count'])); ?> <small><?php echo e($item['percentage']); ?>%</small></strong></div>
                                <div class="report-bar-track"><span class="report-bar-fill tone-<?php echo e($set['tone']); ?>" style="width: <?php echo e(($item['count'] / $maxCount) * 100); ?>%"></span></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="report-empty">No records in this period.</p>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="report-performance-grid">
        <article class="panel report-performance-card">
            <span class="eyebrow">DISPATCH RESPONSE</span>
            <strong><?php echo e($summary['average_response_minutes'] !== null ? number_format($summary['average_response_minutes'], 1).' min' : '—'); ?></strong>
            <p>Average time from incident report to first unit en route</p>
            <small>Based on <?php echo e(number_format($summary['jobs_with_response_time'])); ?> incidents with recorded response transitions.</small>
        </article>
        <article class="panel report-performance-card">
            <span class="eyebrow">INCIDENT RESOLUTION</span>
            <strong><?php echo e($summary['average_resolution_minutes'] !== null ? number_format($summary['average_resolution_minutes'], 1).' min' : '—'); ?></strong>
            <p>Average time from incident report to all units completed</p>
            <small>Based on <?php echo e(number_format($summary['jobs_with_resolution_time'])); ?> incidents with recorded completion transitions.</small>
        </article>
        <article class="panel report-performance-card">
            <span class="eyebrow">DUPLICATE REPORTS</span>
            <strong><?php echo e(number_format($summary['duplicate_jobs'])); ?></strong>
            <p>Incidents closed after confirmation of an existing report</p>
            <small>Duplicates remain separate from transferred-to-112 incidents.</small>
        </article>
    </section>

    <section class="panel report-station-panel">
        <div class="report-panel-heading"><div><h2>Station deployment workload</h2><p>Unit assignments created for incidents in the selected period</p></div></div>
        <?php if(count($report['stations'])): ?>
            <div class="table-scroll"><table><thead><tr><th>Fire station</th><th>Deployments</th><th>Completed deployments</th><th>Completion rate</th></tr></thead><tbody>
                <?php $__currentLoopData = $report['stations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e($station['name']); ?></strong><small><?php echo e($station['code']); ?></small></td>
                        <td><?php echo e(number_format($station['deployments'])); ?></td>
                        <td><?php echo e(number_format($station['completed_deployments'])); ?></td>
                        <td><?php echo e($station['deployments'] ? number_format($station['completed_deployments'] / $station['deployments'] * 100, 1).'%' : '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div>
        <?php else: ?>
            <p class="report-empty">No stations are available in your access scope.</p>
        <?php endif; ?>
    </section>
    <p class="report-footnote">All figures use incident-reported date and your authorized station scope. Response and resolution averages are descriptive operational metrics, not SLA guarantees.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/reports/operations.blade.php ENDPATH**/ ?>