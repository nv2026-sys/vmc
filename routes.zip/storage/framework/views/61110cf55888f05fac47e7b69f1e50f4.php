<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>VMC Operations Report</title>
    <style>
        body { color: #172033; font-family: DejaVu Sans, sans-serif; font-size: 9px; }
        h1 { color: #123d72; font-size: 20px; margin: 0 0 8px; }
        h2 { background: #eaf1f8; color: #123d72; font-size: 12px; margin: 18px 0 6px; padding: 6px; }
        .meta { color: #526174; margin-bottom: 12px; }
        table { border-collapse: collapse; margin-bottom: 10px; width: 100%; }
        th, td { border: 1px solid #d5deea; padding: 5px 7px; text-align: left; }
        th { background: #f3f6fa; }
        .note { color: #526174; font-size: 8px; margin-top: 16px; }
        thead { display: table-header-group; }
        tr { page-break-inside: avoid; }
    </style>
</head>
<body>
    <h1>VMC Operations Report</h1>
    <div class="meta">
        Period: <?php echo e($report['filters']['from']); ?> to <?php echo e($report['filters']['to']); ?><br>
        Station: <?php echo e($stationName); ?>

    </div>
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($section['title']); ?></h2>
        <?php if($section['rows'] !== []): ?>
            <table>
                <thead><tr><?php $__currentLoopData = $section['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($header); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $section['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><?php echo e(is_numeric($value) ? $value : (string) $value); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No records for this section.</p>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="note">Response and resolution averages are descriptive operational metrics based on recorded transitions. They are not SLA guarantees.</p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\vmc\resources\views/reports/operations-export.blade.php ENDPATH**/ ?>