<?php $__env->startSection('title', ($record ? 'Edit ' : 'Add ').$title); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack">
    <div class="page-heading">
        <div>
            <span class="eyebrow">MASTER DATA · <?php echo e(strtoupper($kind)); ?></span>
            <h1><?php echo e($record ? 'Edit '.$title : 'Add '.$title); ?></h1>
            <p class="muted">Changes are permission-checked, station-scoped, and recorded in the audit log.</p>
        </div>
    </div>
    <section class="panel form-panel">
        <form class="managed-user-form" method="POST" action="<?php echo e($record ? route('app.'.$kind.'.update', $record->id) : route('app.'.$kind.'.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($record): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert" role="alert"><strong>Check the form:</strong> <?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <div class="form-grid">
                <?php if($kind === 'stations'): ?>
                    <div class="field"><label for="code">Station code</label><input id="code" name="code" value="<?php echo e(old('code', $record?->code)); ?>" maxlength="30" required><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="name">Station name</label><input id="name" name="name" value="<?php echo e(old('name', $record?->name)); ?>" maxlength="255" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="contact_number">Contact number</label><input id="contact_number" name="contact_number" value="<?php echo e(old('contact_number', $record?->contact_number)); ?>" maxlength="32" autocomplete="tel"><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="address">Address</label><textarea id="address" name="address" rows="3" maxlength="2000" required><?php echo e(old('address', $record?->address)); ?></textarea><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="latitude">Latitude</label><input id="latitude" name="latitude" type="number" step="any" min="-90" max="90" value="<?php echo e(old('latitude', $record?->latitude)); ?>"><?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="longitude">Longitude</label><input id="longitude" name="longitude" type="number" step="any" min="-180" max="180" value="<?php echo e(old('longitude', $record?->longitude)); ?>"><?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <?php elseif($kind === 'wards'): ?>
                    <div class="field"><label for="code">Ward code</label><input id="code" name="code" value="<?php echo e(old('code', $record?->code)); ?>" maxlength="30" required><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="name">Ward name</label><input id="name" name="name" value="<?php echo e(old('name', $record?->name)); ?>" maxlength="255" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field field-wide"><label for="description">Description</label><textarea id="description" name="description" rows="3" maxlength="2000"><?php echo e(old('description', $record?->description)); ?></textarea><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <?php elseif($kind === 'vehicles'): ?>
                    <div class="field"><label for="vehicle_number">Vehicle number</label><input id="vehicle_number" name="vehicle_number" value="<?php echo e(old('vehicle_number', $record?->vehicle_number)); ?>" maxlength="40" required><?php $__errorArgs = ['vehicle_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="vehicle_type">Vehicle type</label><select id="vehicle_type" name="vehicle_type" required><option value="">Select type</option><?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($type); ?>" <?php if(old('vehicle_type', $record?->vehicle_type) === $type): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $type)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="registration_number">Registration number</label><input id="registration_number" name="registration_number" value="<?php echo e(old('registration_number', $record?->registration_number)); ?>" maxlength="40"><?php $__errorArgs = ['registration_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="gps_device_id">GPS device ID</label><input id="gps_device_id" name="gps_device_id" value="<?php echo e(old('gps_device_id', $record?->gps_device_id)); ?>" maxlength="100"><?php $__errorArgs = ['gps_device_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="fire_station_id">Assigned station</label><select id="fire_station_id" name="fire_station_id" required><option value="">Select station</option><?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($station->id); ?>" <?php if((int) old('fire_station_id', $record?->fire_station_id) === $station->id): echo 'selected'; endif; ?>><?php echo e($station->name); ?> · <?php echo e($station->code); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['fire_station_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="status">Status</label><select id="status" name="status" required><?php $__currentLoopData = $vehicleStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(old('status', $record?->status ?? 'AVAILABLE') === $status): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $status)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="latitude">Latitude</label><input id="latitude" name="latitude" type="number" step="any" min="-90" max="90" value="<?php echo e(old('latitude', $record?->latitude)); ?>"><?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="longitude">Longitude</label><input id="longitude" name="longitude" type="number" step="any" min="-180" max="180" value="<?php echo e(old('longitude', $record?->longitude)); ?>"><?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="last_service_at">Last service date</label><input id="last_service_at" name="last_service_at" type="date" value="<?php echo e(old('last_service_at', $record?->last_service_at?->format('Y-m-d'))); ?>"><?php $__errorArgs = ['last_service_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <?php else: ?>
                    <div class="field"><label for="name">Team name</label><input id="name" name="name" value="<?php echo e(old('name', $record?->name)); ?>" maxlength="255" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="fire_station_id">Assigned station</label><select id="fire_station_id" name="fire_station_id" required><option value="">Select station</option><?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($station->id); ?>" <?php if((int) old('fire_station_id', $record?->fire_station_id) === $station->id): echo 'selected'; endif; ?>><?php echo e($station->name); ?> · <?php echo e($station->code); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['fire_station_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="leader_user_id">Team leader</label><select id="leader_user_id" name="leader_user_id"><option value="">Not assigned</option><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($user->id); ?>" <?php if((int) old('leader_user_id', $record?->leader_user_id) === $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['leader_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="contact_number">Contact number</label><input id="contact_number" name="contact_number" value="<?php echo e(old('contact_number', $record?->contact_number)); ?>" maxlength="32"><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="field"><label for="status">Status</label><select id="status" name="status" required><?php $__currentLoopData = $teamStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(old('status', $record?->status ?? 'AVAILABLE') === $status): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $status)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <?php endif; ?>
            </div>

            <?php if($kind === 'wards'): ?>
                <?php ($selectedStations = collect(old('station_ids', $record?->fireStations->modelKeys() ?? []))->map(fn ($id) => (int) $id)->all()); ?>
                <fieldset class="station-fieldset">
                    <legend>Assigned stations <span>Select at least one station in your scope.</span></legend>
                    <?php $__errorArgs = ['station_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="station-choice-grid">
                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="station-choice"><input type="checkbox" name="station_ids[]" value="<?php echo e($station->id); ?>" <?php if(in_array($station->id, $selectedStations, true)): echo 'checked'; endif; ?>><span><strong><?php echo e($station->name); ?></strong><small><?php echo e($station->code); ?></small></span></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </fieldset>
            <?php endif; ?>

            <?php if($kind === 'teams'): ?>
                <?php ($selectedMembers = collect(old('member_ids', $record?->members->modelKeys() ?? []))->map(fn ($id) => (int) $id)->all()); ?>
                <fieldset class="station-fieldset">
                    <legend>Team members <span>Only active users from the selected station can be assigned.</span></legend>
                    <?php $__errorArgs = ['member_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="station-choice-grid">
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <label class="station-choice"><input type="checkbox" name="member_ids[]" value="<?php echo e($user->id); ?>" <?php if(in_array($user->id, $selectedMembers, true)): echo 'checked'; endif; ?>><span><strong><?php echo e($user->name); ?></strong><small>Active station user</small></span></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="muted">No active station users are available to assign.</p>
                        <?php endif; ?>
                    </div>
                </fieldset>
            <?php endif; ?>

            <?php if(in_array($kind, ['stations', 'wards'], true)): ?>
                <label class="active-choice">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $record?->is_active ?? true)): echo 'checked'; endif; ?>>
                    <span><strong><?php echo e($kind === 'stations' ? 'Station active' : 'Ward active'); ?></strong><small>Inactive records are hidden from operational assignment and station coverage.</small></span>
                </label>
            <?php endif; ?>

            <div class="form-actions">
                <a class="button button-light" href="<?php echo e(route('app.'.$kind)); ?>">Cancel</a>
                <button class="button button-primary" type="submit"><?php echo e($record ? 'Save changes' : 'Create '.$title); ?></button>
            </div>
        </form>

        <?php if($record): ?>
            <form method="POST" action="<?php echo e(route('app.'.$kind.'.destroy', $record->id)); ?>" class="archive-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <p>Archive removes the record from active directories. Records linked to operational history cannot be archived.</p>
                <button class="button button-danger" type="submit">Archive <?php echo e(strtolower($title)); ?></button>
            </form>
        <?php endif; ?>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/master-data/form.blade.php ENDPATH**/ ?>