<?php

namespace App\Services;

use App\Models\JobAssignment;
use App\Models\User;
use App\Models\Vehicle;
use App\Models\VehicleStatusHistory;
use Illuminate\Support\Facades\DB;

class VehicleStatusWorkflow
{
    public function __construct(private readonly AuditLogger $auditLogger) {}

    public function updateForDriver(User $actor, Vehicle $requestedVehicle, string $status): ?VehicleStatusHistory
    {
        abort_unless($actor->hasRole('VEHICLE_DRIVER'), 403);

        return DB::transaction(function () use ($actor, $requestedVehicle, $status): ?VehicleStatusHistory {
            $vehicle = $this->findDriverLinkedVehicle($actor, true);
            abort_unless($vehicle && (int) $vehicle->id === (int) $requestedVehicle->id, 404);

            return $this->setStatus($actor, $vehicle, $status, 'api');
        });
    }

    public function markLinkedVehicleOffRoadOnLogout(User $actor): ?VehicleStatusHistory
    {
        if (! $actor->hasRole('VEHICLE_DRIVER')) {
            return null;
        }

        return DB::transaction(function () use ($actor): ?VehicleStatusHistory {
            $vehicle = $this->findDriverLinkedVehicle($actor, true);
            if (! $vehicle) {
                return null;
            }

            return $this->setStatus(
                $actor,
                $vehicle,
                Vehicle::OPERATIONAL_STATUS_OFF_ROAD,
                'logout',
                true,
            );
        });
    }

    public function findDriverLinkedVehicle(User $driver, bool $lock = false): ?Vehicle
    {
        $assignment = JobAssignment::query()
            ->where('assigned_driver_user_id', $driver->id)
            ->whereNull('released_at')
            ->orderByDesc('assigned_at')
            ->orderByDesc('id')
            ->first();

        $assignment ??= JobAssignment::query()
            ->where('assigned_driver_user_id', $driver->id)
            ->orderByDesc('assigned_at')
            ->orderByDesc('id')
            ->first();

        if (! $assignment) {
            return null;
        }

        $vehicleQuery = Vehicle::query()->whereKey($assignment->vehicle_id);
        if ($lock) {
            $vehicleQuery->lockForUpdate();
        }

        return $vehicleQuery->first();
    }

    private function setStatus(
        User $actor,
        Vehicle $vehicle,
        string $status,
        string $source,
        bool $recordUnchanged = false,
    ): ?VehicleStatusHistory {
        $previousStatus = $vehicle->operational_status;
        if ($previousStatus === $status && ! $recordUnchanged) {
            return null;
        }

        $vehicle->update(['operational_status' => $status]);
        $history = $vehicle->statusHistory()->create([
            'previous_status' => $previousStatus,
            'new_status' => $status,
            'changed_by' => $actor->id,
            'changed_at' => now(),
            'source' => $source,
        ]);

        $this->auditLogger->record($actor, 'vehicles.road_status_changed', $vehicle, [
            'previous_status' => $previousStatus,
            'new_status' => $status,
            'source' => $source,
        ]);

        return $history;
    }
}
