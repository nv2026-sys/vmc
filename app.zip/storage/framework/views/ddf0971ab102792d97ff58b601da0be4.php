

<?php $__env->startSection('title', 'Incident Reports'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $summary = $report['summary'];
    $filters = $report['filters'];
    $metrics = [
        ['Total Incidents', $summary['total_jobs'], 'tone-blue'],
        ['Critical Incidents', $summary['critical_jobs'], 'tone-red'],
        ['High Priority Incidents', $summary['high_jobs'], 'tone-orange'],
        ['Resolved Incidents', $summary['resolved_jobs'], 'tone-green'],
        ['Pending Incidents', $summary['pending_jobs'], 'tone-purple'],
        ['Average Response Time', $summary['average_response_minutes'] === null ? '—' : number_format($summary['average_response_minutes'], 1).' min', 'tone-cyan'],
        ['Average Resolution Time', $summary['average_resolution_minutes'] === null ? '—' : number_format($summary['average_resolution_minutes'], 1).' min', 'tone-blue'],
    ];
    $statusLabels = [
        'RECEIVED' => 'Received',
        'ASSIGNED' => 'Assigned',
        'EN_ROUTE' => 'En Route',
        'ARRIVED' => 'Arrived',
        'IN_PROGRESS' => 'In Progress',
        'COMPLETED' => 'Completed',
        'DUPLICATE' => 'Duplicate',
        'TRANSFERRED_TO_112' => 'Transferred to 112',
    ];
    $priorityLabels = [
        'CRITICAL' => 'Critical',
        'HIGH' => 'High',
        'MEDIUM' => 'Medium',
        'LOW' => 'Low',
        'NORMAL' => 'Normal',
        'URGENT' => 'Urgent',
    ];
    $query = request()->query();
?>
<section class="page-stack operations-reports" data-data-url="<?php echo e(route('app.reports.data')); ?>">
    <div class="page-heading">
        <div>
            <span class="eyebrow">VADODARA MUNICIPAL CORPORATION · REPORTING</span>
            <h1>Incident Reports</h1>
            <p class="muted">View, Filter and Analyze Incident Records.</p>
        </div>
        <div class="report-heading-actions">
            <?php if(auth()->user()->hasPermission('reports.export')): ?>
                <div class="report-export-actions" aria-label="Export report">
                    <a class="button button-light" href="<?php echo e(route('app.reports.export', ['format' => 'xlsx'] + $query)); ?>">Export Excel</a>
                    <a class="button button-light" href="<?php echo e(route('app.reports.export', ['format' => 'pdf'] + $query)); ?>">Export PDF</a>
                    <a class="button button-light" href="<?php echo e(route('app.reports.export', ['format' => 'csv'] + $query)); ?>">Export CSV</a>
                </div>
            <?php endif; ?>
            <button class="button button-light" type="button" data-report-print>Print Report</button>
            <span class="report-period"><?php echo e(\Illuminate\Support\Carbon::parse($filters['from'])->format('M j')); ?> – <?php echo e(\Illuminate\Support\Carbon::parse($filters['to'])->format('M j, Y')); ?></span>
        </div>
    </div>
    <?php if($errors->any()): ?> <div class="alert" role="alert"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    <form method="GET" action="<?php echo e(route('app.reports')); ?>" class="panel report-filter-form" data-report-filters>
        <label>From Date<input type="date" name="from" value="<?php echo e($filters['from']); ?>" required></label>
        <label>To Date<input type="date" name="to" value="<?php echo e($filters['to']); ?>" required></label>
        <label>Ward
            <select name="ward_id">
                <option value="">All Wards</option>
                <?php $__currentLoopData = $report['wards_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ward['id']); ?>" <?php if($filters['ward_id'] === $ward['id']): echo 'selected'; endif; ?>><?php echo e($ward['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>Area / Location<input type="search" name="area" value="<?php echo e($filters['area']); ?>" maxlength="150" placeholder="Search address or area"></label>
        <label>Incident Type
            <select name="incident_type">
                <option value="">All Types</option>
                <?php $__currentLoopData = $report['incident_types_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type); ?>" <?php if($filters['incident_type'] === $type): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $type)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>Priority
            <select name="priority">
                <option value="">All Priorities</option>
                <?php $__currentLoopData = $report['priorities_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($priority); ?>" <?php if($filters['priority'] === $priority): echo 'selected'; endif; ?>><?php echo e($priorityLabels[$priority] ?? str_replace('_', ' ', $priority)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>Incident Status
            <select name="status">
                <option value="">All Statuses</option>
                <?php $__currentLoopData = $report['statuses_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if($filters['status'] === $status): echo 'selected'; endif; ?>><?php echo e($statusLabels[$status] ?? str_replace('_', ' ', $status)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>Assigned Vehicle
            <select name="vehicle_id">
                <option value="">All Vehicles</option>
                <?php $__currentLoopData = $report['vehicles_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vehicle['id']); ?>" <?php if($filters['vehicle_id'] === $vehicle['id']): echo 'selected'; endif; ?>><?php echo e($vehicle['vehicle_number']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>Caller Name / Phone<input type="search" name="caller" value="<?php echo e($filters['caller']); ?>" maxlength="120" placeholder="Search caller"></label>
        <label>Fire Station
            <select name="station_id">
                <option value="">All accessible stations</option>
                <?php $__currentLoopData = $report['stations_available']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($station['id']); ?>" <?php if($filters['station_id'] === $station['id']): echo 'selected'; endif; ?>><?php echo e($station['name']); ?> · <?php echo e($station['code']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <div class="report-filter-actions">
            <button class="button button-primary" type="submit">Generate Report</button>
            <a class="button button-light" data-report-reset href="<?php echo e(route('app.reports')); ?>">Reset Filters</a>
        </div>
    </form>

    <div class="report-stat-grid report-stat-grid-seven">
        <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $tone]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="report-stat-card"><span class="report-stat-icon <?php echo e($tone); ?>">▦</span><div><small><?php echo e($label); ?></small><strong><?php echo e(is_numeric($value) ? number_format($value) : $value); ?></strong></div></article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="panel report-data-panel">
        <div class="report-panel-heading">
            <div><h2>Incident Summary Report</h2><p>Server-paginated incidents matching the selected filters</p></div>
            <label class="report-table-search">Search this report<input type="search" data-report-search placeholder="Search incident, caller, ward…"></label>
        </div>
        <div class="report-table-status" data-report-status role="status" aria-live="polite"></div>
        <div class="table-scroll report-table-scroll">
            <table class="report-record-table">
                <thead><tr>
                    <th>Sr. No.</th><th data-order-column="1">Incident ID</th><th data-order-column="2">Incident Date &amp; Time</th><th data-order-column="3">Incident Type</th><th data-order-column="4">Incident Details</th><th data-order-column="5">Location</th><th data-order-column="6">Ward</th><th data-order-column="7">Caller Name</th><th data-order-column="8">Caller Phone</th><th data-order-column="9">Priority</th><th data-order-column="10">Assigned Vehicle</th><th>Vehicle Status</th><th data-order-column="12">Incident Status</th><th>Response Time</th><th>Elapsed Time</th><th>Resolution Time</th><th>Action</th>
                </tr></thead>
                <tbody data-report-rows><tr><td colspan="17" class="empty-cell">Loading incident records…</td></tr></tbody>
            </table>
        </div>
        <div class="report-table-pagination">
            <span data-report-count>—</span>
            <div><button type="button" data-report-prev disabled>Previous</button><span data-report-page>Page 1</span><button type="button" data-report-next disabled>Next</button></div>
        </div>
    </section>

    <section class="panel report-data-panel">
        <div class="report-panel-heading"><div><h2>Ward-wise Incident Report</h2><p>Counts and recorded response/resolution times by ward</p></div></div>
        <div class="table-scroll"><table><thead><tr><th>Sr. No.</th><th>Ward Name</th><th>Total Incidents</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th><th>Resolved</th><th>Pending</th><th>Avg. Response</th><th>Avg. Resolution</th><th>Action</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $report['wards']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td><?php echo e($index + 1); ?></td><td><?php echo e($ward['ward']); ?></td><td><?php echo e($ward['total']); ?></td><td><?php echo e($ward['critical']); ?></td><td><?php echo e($ward['high']); ?></td><td><?php echo e($ward['medium']); ?></td><td><?php echo e($ward['low']); ?></td><td><?php echo e($ward['resolved']); ?></td><td><?php echo e($ward['pending']); ?></td><td><?php echo e($ward['average_response'] === null ? '—' : number_format($ward['average_response'], 1).' min'); ?></td><td><?php echo e($ward['average_resolution'] === null ? '—' : number_format($ward['average_resolution'], 1).' min'); ?></td><td><?php if($ward['ward_id']): ?><a class="button button-light button-small" href="<?php echo e(route('app.reports', array_merge($query, ['ward_id' => $ward['ward_id']]))); ?>">View Details</a><?php else: ?> — <?php endif; ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="12" class="empty-cell">No ward records match these filters.</td></tr>
                <?php endif; ?>
            </tbody>
        </table></div>
    </section>

    <div class="report-breakdown-grid report-breakdown-grid-two">
        <section class="panel report-data-panel">
            <div class="report-panel-heading"><div><h2>Incident Type-wise Report</h2><p>Actual incident types in the selected records</p></div></div>
            <div class="table-scroll"><table><thead><tr><th>Incident Type</th><th>Total Cases</th><th>Resolved</th><th>Pending</th><th>Avg. Response</th><th>% Total</th></tr></thead>
                <tbody><?php $__empty_1 = true; $__currentLoopData = $report['type_reports']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($item['type']); ?></td><td><?php echo e($item['total']); ?></td><td><?php echo e($item['resolved']); ?></td><td><?php echo e($item['pending']); ?></td><td><?php echo e($item['average_response'] === null ? '—' : number_format($item['average_response'], 1).' min'); ?></td><td><?php echo e(number_format($item['percentage'], 1)); ?>%</td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty-cell">No incident types match these filters.</td></tr><?php endif; ?></tbody>
            </table></div>
        </section>
        <section class="panel report-data-panel">
            <div class="report-panel-heading"><div><h2>Priority-wise Report</h2><p>Resolved and pending counts by recorded priority</p></div></div>
            <div class="table-scroll"><table><thead><tr><th>Priority</th><th>Total Cases</th><th>Resolved</th><th>Pending</th></tr></thead>
                <tbody><?php $__empty_1 = true; $__currentLoopData = $report['priority_reports']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><span class="report-priority-badge is-<?php echo e(\Illuminate\Support\Str::slug($item['priority'])); ?>"><?php echo e($priorityLabels[$item['priority']] ?? $item['priority']); ?></span></td><td><?php echo e($item['total']); ?></td><td><?php echo e($item['resolved']); ?></td><td><?php echo e($item['pending']); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="empty-cell">No priority records match these filters.</td></tr><?php endif; ?></tbody>
            </table></div>
        </section>
    </div>

    <section class="panel report-data-panel">
        <div class="report-panel-heading"><div><h2>Vehicle-wise Incident Report</h2><p>Assignment and working-duration data from recorded vehicle timelines</p></div></div>
        <div class="table-scroll"><table><thead><tr><th>Vehicle Number</th><th>Assigned Incidents</th><th>Completed</th><th>Pending</th><th>Avg. Pickup</th><th>Avg. Response</th><th>Avg. Resolution</th><th>Total Working Hours</th><th>Action</th></tr></thead>
            <tbody><?php $__empty_1 = true; $__currentLoopData = $report['vehicle_reports']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><a href="<?php echo e(route('app.reports', array_merge($query, ['vehicle_id' => $vehicle['vehicle_id']]))); ?>"><?php echo e($vehicle['vehicle']); ?></a></td><td><?php echo e($vehicle['total']); ?></td><td><?php echo e($vehicle['completed']); ?></td><td><?php echo e($vehicle['pending']); ?></td><td><?php echo e($vehicle['average_pickup'] === null ? '—' : number_format($vehicle['average_pickup'], 1).' min'); ?></td><td><?php echo e($vehicle['average_response'] === null ? '—' : number_format($vehicle['average_response'], 1).' min'); ?></td><td><?php echo e($vehicle['average_resolution'] === null ? '—' : number_format($vehicle['average_resolution'], 1).' min'); ?></td><td><?php echo e(number_format($vehicle['working_hours'], 1)); ?></td><td><a class="button button-light button-small" href="<?php echo e(route('app.reports', array_merge($query, ['vehicle_id' => $vehicle['vehicle_id']]))); ?>">View Incidents</a></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="9" class="empty-cell">No vehicle assignments match these filters.</td></tr><?php endif; ?></tbody>
        </table></div>
    </section>

    <section class="panel report-data-panel">
        <div class="report-panel-heading"><div><h2>Response Time Report</h2><p>Pickup: created to assigned · Response: created to vehicle arrival · Resolution: created to completed</p></div></div>
        <div class="table-scroll"><table><thead><tr><th>Incident ID</th><th>Ward</th><th>Incident Type</th><th>Created</th><th>Assigned</th><th>Vehicle Departure</th><th>Arrival</th><th>Pickup Time</th><th>Response Time</th><th>Resolution Time</th><th>Vehicle</th></tr></thead>
            <tbody><?php $__empty_1 = true; $__currentLoopData = $report['response_reports']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><a href="<?php echo e($item['view_url']); ?>"><?php echo e($item['job_id']); ?></a></td><td><?php echo e($item['ward'] ?? '—'); ?></td><td><?php echo e($item['type']); ?></td><td><?php echo e($item['created_at']?->format('M j, Y H:i') ?? '—'); ?></td><td><?php echo e($item['assigned_at']?->format('M j, Y H:i') ?? '—'); ?></td><td><?php echo e($item['departure_at']?->format('M j, Y H:i') ?? '—'); ?></td><td><?php echo e($item['arrival_at']?->format('M j, Y H:i') ?? '—'); ?></td><td><?php echo e($item['pickup_minutes'] === null ? '—' : number_format($item['pickup_minutes'], 1).' min'); ?></td><td><?php echo e($item['response_minutes'] === null ? '—' : number_format($item['response_minutes'], 1).' min'); ?></td><td><?php echo e($item['resolution_minutes'] === null ? '—' : number_format($item['resolution_minutes'], 1).' min'); ?></td><td><?php echo e($item['vehicle_number'] ?? '—'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="11" class="empty-cell">No incident timelines match these filters.</td></tr><?php endif; ?></tbody>
        </table></div>
    </section>

    <p class="report-footnote">All data respects your authorized station scope. Pickup, response, resolution and working-time values are shown only when supported by recorded assignment/status timestamps.</p>
</section>
<script defer src="<?php echo e(asset('reports.js')); ?>?v=<?php echo e(filemtime(public_path('reports.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/reports/operations.blade.php ENDPATH**/ ?>