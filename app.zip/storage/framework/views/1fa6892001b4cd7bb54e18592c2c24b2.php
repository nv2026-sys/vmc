<?php $__env->startSection('title', 'Incident archive'); ?>

<?php $__env->startSection('content'); ?>
<section class="page-stack operations-reports">
    <div class="page-heading">
        <div>
            <span class="eyebrow">RECORDS · CLOSED INCIDENTS</span>
            <h1>Incident archive</h1>
            <p class="muted">Archived incidents retain their call, dispatch, and audit history. Restore a record to return it to the active incident directory.</p>
        </div>
    </div>
    <?php if(session('status')): ?> <div class="success-notice" role="status"><?php echo e(session('status')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?> <div class="alert" role="alert"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    <form method="GET" action="<?php echo e(route('app.archive')); ?>" class="panel report-filter-form archive-search-form">
        <label>Search archived incidents
            <input type="search" name="search" value="<?php echo e($search); ?>" maxlength="100" placeholder="Job ID, caller, phone, area">
        </label>
        <button class="button button-primary" type="submit">Search</button>
        <?php if($search !== ''): ?> <a class="button button-light" href="<?php echo e(route('app.archive')); ?>">Clear</a> <?php endif; ?>
    </form>

    <section class="panel report-station-panel">
        <div class="report-panel-heading">
            <div><h2>Archived incidents</h2><p><?php echo e(number_format($jobs->total())); ?> records in your authorized station scope</p></div>
        </div>
        <?php if($jobs->isNotEmpty()): ?>
            <div class="table-scroll"><table>
                <thead><tr><th>Job ID · reported</th><th>Caller · location</th><th>Type · priority</th><th>Status</th><th>Archived</th><th>Action</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($job->job_id); ?></strong><small><?php echo e($job->occurred_at?->format('M j, Y g:i A')); ?></small></td>
                            <td><strong><?php echo e($job->caller_name); ?></strong><small><?php echo e($job->caller_phone); ?> · <?php echo e($job->society_name ?: $job->ward?->name ?: 'Location not recorded'); ?></small></td>
                            <td><?php echo e(str_replace('_', ' ', $job->incident_type)); ?><small><?php echo e($job->priority); ?> priority</small></td>
                            <td><span class="status"><?php echo e(str_replace('_', ' ', $job->status)); ?></span></td>
                            <td><?php echo e($job->deleted_at?->format('M j, Y g:i A')); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('app.archive.restore', $job->id)); ?>" onsubmit="return confirm('Restore this incident to the active incident directory?');">
                                    <?php echo csrf_field(); ?>
                                    <button class="button button-light" type="submit">Restore</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table></div>
            <?php echo e($jobs->links()); ?>

        <?php else: ?>
            <p class="report-empty">No archived incidents match this search.</p>
        <?php endif; ?>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\vmc\resources\views/archive/index.blade.php ENDPATH**/ ?>