<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>VMC Operations Report</title>
    <style>
        body { color: #172033; font-family: DejaVu Sans, sans-serif; font-size: 7px; }
        h1 { color: #123d72; font-size: 18px; margin: 0 0 8px; }
        h2 { background: #eaf1f8; color: #123d72; font-size: 10px; margin: 15px 0 5px; padding: 5px; }
        .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
        .brand img { height: 42px; }
        .meta { color: #526174; margin-bottom: 10px; line-height: 1.6; }
        table { border-collapse: collapse; margin-bottom: 10px; width: 100%; }
        th, td { border: 1px solid #d5deea; padding: 3px 4px; text-align: left; }
        th { background: #f3f6fa; }
        .note { color: #526174; font-size: 8px; margin-top: 16px; }
        thead { display: table-header-group; }
        tr { page-break-inside: avoid; }
    </style>
</head>
<body>
    <div class="brand">
        <img src="<?php echo e(public_path('images/vadodara-municipal-corporation-logo.jpeg')); ?>" alt="Vadodara Municipal Corporation">
        <h1>Incident Reports</h1>
    </div>
    <div class="meta">
        Period: <?php echo e($report['filters']['from']); ?> to <?php echo e($report['filters']['to']); ?><br>
        Ward: <?php echo e($report['filters']['ward_id'] ? (collect($report['wards_available'])->firstWhere('id', $report['filters']['ward_id'])['name'] ?? 'Selected ward') : 'All wards'); ?><br>
        Station: <?php echo e($stationName); ?><br>
        Generated: <?php echo e(now()->format('Y-m-d H:i:s')); ?><br>
        Total incidents: <?php echo e(number_format($report['summary']['total_jobs'])); ?> · Critical: <?php echo e(number_format($report['summary']['critical_jobs'])); ?> · High: <?php echo e(number_format($report['summary']['high_jobs'])); ?> · Resolved: <?php echo e(number_format($report['summary']['resolved_jobs'])); ?> · Pending: <?php echo e(number_format($report['summary']['pending_jobs'])); ?>

    </div>
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($section['title']); ?></h2>
        <?php if($section['rows'] !== []): ?>
            <table>
                <thead><tr><?php $__currentLoopData = $section['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($header); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $section['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><?php echo e(is_numeric($value) ? $value : (string) $value); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No records for this section.</p>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="note">Response and resolution averages are descriptive operational metrics based on recorded transitions. They are not SLA guarantees.</p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\vmc\resources\views/reports/operations-export.blade.php ENDPATH**/ ?>